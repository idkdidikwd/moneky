# Grand Line: Quake & Azure

A Fabric 26.3 vertical-slice combat mod centered on two Devil Fruits: the Gura Gura no Mi and the Uo Uo no Mi, Model: Seiryu.

**Target:** Minecraft 26.3 · Fabric Loader 0.19.5 · Fabric API 0.161.0+26.3 · Java 25.

The source tree deliberately separates server-owned power state/combat/destruction from client rendering, HUD, key mappings and camera/pose work. It includes custom fruit assets, 20 ability icons, original sound assets, staged world-space VFX, multipart Hybrid/Dragon rigs, server-authoritative destruction and a release QA script.

## Controls

The five ability mappings default to **Z / X / C / V / B** and are normal Minecraft key mappings, so they can be rebound in Controls. In Full Dragon form, movement uses the normal movement/jump/sneak inputs and holding the normal attack input activates the sustained breath when allowed. Sneak + slot 5 steps down one Seiryu transformation tier.

## Building

A release build requires JDK 25 and Gradle 9.6.0. The CI workflow provisions both and runs:

```text
gradle --no-daemon --stacktrace clean build
```

It then starts a headless dedicated-server smoke test, verifies the remapped JAR metadata, computes SHA-256, and uploads the distributable plus QA logs. `tools/verify_release.py` is an additional static/resource audit; it is intentionally not treated as a substitute for compilation or in-game testing.

## Installation

Once a verified release JAR exists, install Fabric Loader 0.19.5 for Minecraft 26.3, install the matching Fabric API, place the mod JAR in the instance `mods` directory, and launch with Java 25.

## QA

See `docs/REQUIREMENTS_MATRIX.md` for the master-brief traceability matrix and the mandatory in-game validation pass.
