# Grand Line: Quake & Azure — Requirement / Evidence Matrix

This ledger exists so the 55-section master build brief is treated as a release checklist rather than as inspiration. It deliberately distinguishes **implemented/static evidence** from **runtime/build verification**. A static pass is not a substitute for a real Fabric build or in-game test.

Status vocabulary: **IMPLEMENTED** = source/assets exist and the static QA script checks representative evidence; **CI-READY** = an automated runtime/build check is prepared but has not been observed passing in the current offline container; **RUNTIME-PENDING** = only a real Minecraft run can close the gate; **BUILD-PENDING** = requires JDK 25 + Gradle/dependency access.

| Brief section | Requirement preserved | Evidence in project | Gate |
|---|---|---|---|
| 1 Target environment | Exact screenshot target; no loader guessing | `gradle.properties`, `fabric.mod.json`: Minecraft 26.3, Fabric Loader 0.19.5, Fabric API 0.161.0+26.3; Java 25; Loom 1.17.21 | IMPLEMENTED / BUILD-PENDING |
| 2 Delivery | Real compiled installable JAR, fixes, tests, verified artifact, source retained | `.github/workflows/release-build.yml` performs clean build, smoke test, artifact inspection and SHA-256; source tree retained | CI-READY / BUILD-PENDING |
| 3 Workflow | Research → architecture → implementation → integration → polish → testing → release | Separated systems, static QA, build CI, release audit | IMPLEMENTED / RUNTIME-PENDING |
| 4 Creative authority | Faithful recognizable identities; canon-compatible extensions instead of invented “canon” | Distinct Gura/Seiryu ability families and form-specific move sets | IMPLEMENTED |
| 5 Artistic north star | Anticipation → release → impact → reaction → aftermath; 3D/2D/world/camera/audio layers | `GuraAbilities`, `SeiryuAbilities`, `DisplayFx`, `FractureFx`, `WorldOps`, camera mixins, original sounds | IMPLEMENTED / RUNTIME-PENDING |
| 6 VFX quality | No generic spam; recognizable silhouettes; 3D depth/parallax; expanding fractures | world-space block-display rings/crescents/fracture branches/plates; quality scaling | IMPLEMENTED / RUNTIME-PENDING |
| 7 Animation | First/third person, observers, anticipation/release/recovery, eating, transforms, flight/locomotion, poses | `FirstPersonHandsMixin`, `PlayerModelMixin`, multipart transformation rigs, action state sync | IMPLEMENTED / RUNTIME-PENDING |
| 8 Fruit acquisition | Two obtainable custom fruit items with intentional assets | `ModItems`, custom item models/textures, creative-tab registration | IMPLEMENTED |
| 9 Eating | No powers before eating; authored sequence; nausea/VFX/sound; persistent/synced assignment; one fruit | `DevilFruitItem`, `PowerState`; cooldown reset; one-fruit guard | IMPLEMENTED / RUNTIME-PENDING |
| 10 HUD | Bottom-right five-slot UI with icon/name/key/cooldown/ready/charge/unavailable/form state | `AbilityHud` + 20 ability icons; dynamic Human/Hybrid/Dragon families | IMPLEMENTED / RUNTIME-PENDING |
| 11 Keybinds | Five normal configurable/rebindable mappings | `ModKeyMappings`, Fabric keymapping registry; Z/X/C/V/B defaults | IMPLEMENTED / RUNTIME-PENDING |
| 12 Combat | Server-authoritative validation, damage, knockback, cooldown/startup/recovery/range/filtering | `AbilityEngine`, serverbound payloads, `WorldOps`, per-ability catalog | IMPLEMENTED / RUNTIME-PENDING |
| 13 Gura identity | Vibration/pressure/spatial fracture/seismic structural failure, not recolored explosions | No vanilla explosion calls; dedicated fracture/pressure/destruction systems | IMPLEMENTED |
| 14 Quake sphere | Layered unstable hand-bound hypocenter with orbiting fragments, rings, microfractures and transfer | `hypocenter` uses three orbits, pressure shell, microfractures and hand→target transfer rings | IMPLEMENTED / RUNTIME-PENDING |
| 15 Air shattering | Staged world-space fracture with depth, branch propagation, separating plates and shock beyond crack | `FractureFx.bloom`, `airBreak` timed crack phases and travelling shock front | IMPLEMENTED / RUNTIME-PENDING |
| 16 Gura five moves | Distinct Quake Fist, Air Break, Ground Rupture, Repulsion, World Shaker | `GuraAbilities` five separate mechanics with unique action IDs and cooldown entries | IMPLEMENTED / RUNTIME-PENDING |
| 17 Destruction | Real staged server edits; unbreakables/block entities/chunks/fluids protected; configurable griefing; capped work | `DestructionManager`, `DestructionProtectionCallback`, visual/world separation | IMPLEMENTED / RUNTIME-PENDING |
| 18 Seiryu states | Human → Hybrid → Full Dragon, each with different gameplay/HUD/model/camera/VFX | form attachment, catalog, transformation rig manager, dynamic HUD | IMPLEMENTED / RUNTIME-PENDING |
| 19 Base passive | Slightly stronger unarmed combat, directional claw arc, material-aware impacts | entity passive + `passiveClawBlock` using struck `BlockState` particle option | IMPLEMENTED / RUNTIME-PENDING |
| 20 Base abilities | Four canon-compatible human manifestations without stealing strongest later moves | Azure Claw, Scale Bastion, Flame Cloud Step, Dragon Pulse | IMPLEMENTED / RUNTIME-PENDING |
| 21 Hybrid transform | Buildup, Haki-like energy, dust push, scales/claws/horns/tail, final shockwave, observer visibility | staged `transformHybrid`; synced form + custom rig | IMPLEMENTED / RUNTIME-PENDING |
| 22 Hybrid model | Large custom transformed silhouette with scales/horns/claws/tail/fangs/proportions | multipart block-display rig + interaction hitboxes; not scaled Steve | IMPLEMENTED / RUNTIME-PENDING |
| 23 Hybrid camera | Adapted first/rear/front camera, collision, FOV, attack/transformation framing | `CameraMixin` + collision-safe max zoom + configurable distance/shake | IMPLEMENTED / RUNTIME-PENDING |
| 24 Hybrid abilities | Thunder Bagua assault, Kundali barrage, compact mouth breath, Vajra ranged force | four dedicated methods, custom rhythms/VFX/Haki language | IMPLEMENTED / RUNTIME-PENDING |
| 25 Full Dragon transform | Clouds/lightning/energy/shockwave/emergent huge body/camera adaptation | staged `transformDragon` with storm rings, lightning, emerging spine, final roar | IMPLEMENTED / RUNTIME-PENDING |
| 26 Full Dragon | Massive articulated serpentine body/head/horns/mane/claws/tail/turn follow-through/jaw/hit solution | 22 body segments, heading history, jaw articulation, interaction proxies | IMPLEMENTED / RUNTIME-PENDING |
| 27 Flame Cloud flight | Accel/decel, vertical movement, turning, animation/cloud/wind/camera/sync | `DragonController` momentum flight + rig flame-cloud VFX | IMPLEMENTED / RUNTIME-PENDING |
| 28 Held M1 breath | Sustained mouth-origin breath, buildup, volume, smoke/heat, damage, ignition/destruction, evolving audio, resource cost | held ATTACK controller, start/loop/end audio, energy drain/lock, mouth origin, cone damage/terrain | IMPLEMENTED / RUNTIME-PENDING |
| 29 Dragon Rush | Giant body used as physical weapon with environmental/entity response | body-line damage sampling, movement burst, dust/destruction | IMPLEMENTED / RUNTIME-PENDING |
| 30 Kaifu | Volumetric cutting crescents with compression/readability and terrain slicing | three fanned world-space crescents + long line destruction | IMPLEMENTED / RUNTIME-PENDING |
| 31 Tatsumaki | Physical rotating flow affecting entities/debris and generated by Dragon action | helical flow + vortex impulses and storm audio | IMPLEMENTED / RUNTIME-PENDING |
| 32 Tatsumaki Kaifu | Dedicated rotating pressure system with cutting arcs and final collapse | independent sequence, storm blades, vortex and terminal pressure event | IMPLEMENTED / RUNTIME-PENDING |
| 33 Flame Dragon ultimate | Giant fiery outer-dragon mantle, heat/fire response, charge/impact/aftermath | staged mantle along serpentine spine, heat rings, charge, impact, ignition/destruction | IMPLEMENTED / RUNTIME-PENDING |
| 34 Haki language | Dark/red violent branching, pressure, flashes, cracks, environment; distinct from normal lightning | red/dark display geometry + `HAKI_CRACK`, impact pressure; no generic lightning entity | IMPLEMENTED / RUNTIME-PENDING |
| 35 Unique effects | Shared infrastructure but distinct artistic behavior between abilities/forms | dedicated per-ability geometry/timing/mechanics; Hybrid vs Full Dragon breath differ | IMPLEMENTED / RUNTIME-PENDING |
| 36 Environmental response | Debris/dust/cracks/wind/scorch/fire/aftershocks without permanent entity litter | transient displays/particles, staged edits, ignition, cleanup ownership tags | IMPLEMENTED / RUNTIME-PENDING |
| 37 Sound | Layered distinct quake/dragon/Haki/flame identities; no ripped commercial audio | 12 original generated/local OGG assets and separate sound events | IMPLEMENTED / RUNTIME-PENDING |
| 38 Camera | Distance-scaled shake, FOV kick, transformation/dragon framing; disable/intensity setting | `CameraMixin`, `ModConfig.cameraShake`, `dragonCameraDistance` | IMPLEMENTED / RUNTIME-PENDING |
| 39 Multiplayer | Server owns state/damage/destruction; client renders; validated requests; sync/cleanup/dedicated-server isolation | split source sets, serverbound payloads, attachments, owner-scoped cinematic cancellation, rig/VFX cleanup | IMPLEMENTED / RUNTIME-PENDING |
| 40 Performance | LOD/quality tiers, lifetime caps, staged edits, no runaway debris/allocations | LOW/MEDIUM/HIGH/CINEMATIC scaling, update throttling, queued destruction budgets, transient lifetimes | IMPLEMENTED / RUNTIME-PENDING |
| 41 Configuration | Terrain/radius/VFX/shake/dragon camera/friendly fire/cooldown controls with sensible defaults | `grandlinequakes.properties` auto-created by `ModConfig` | IMPLEMENTED / RUNTIME-PENDING |
| 42 Architecture | Separate ownership, abilities, cooldowns, forms, network, damage, destruction, animation/rendering/VFX/HUD/input/sound/config | package/system separation across ~30 Java files | IMPLEMENTED |
| 43 Asset quality | No missing/blank/TODO/debug/unfinished slot | static audit decodes/nonblank-checks all required images and all OGG; scans Java hygiene | IMPLEMENTED / RUNTIME-PENDING |
| 44 Asset legality | No ripped commercial One Piece footage/audio/models/textures | project contains original Minecraft-compatible procedural/generated assets only | IMPLEMENTED |
| 45 Testing | Startup, fruits, bindings, every move/form, persistence, terrain cases, multiplayer | static audit + CI clean build/dedicated-server smoke; in-game matrix below remains mandatory | CI-READY / RUNTIME-PENDING |
| 46 Debugging | Fix API/version/network/render/resource/serialization/classloading failures using logs/compiler | CI uses stacktraces and retains smoke log; no “should work” release gate | CI-READY |
| 47 Quality gates | Build/env/fruits/UI/input/animation/Gura/Seiryu/technical gates all closed before release | this matrix + `tools/verify_release.py`; release JAR withheld until real build/test | BUILD-PENDING / RUNTIME-PENDING |
| 48 Tradeoffs | Stability/function/transforms/core animation/signature VFX/destruction/network/performance/embellishment priority | staged/capped world edits, no world rotation hack, configurable spectacle | IMPLEMENTED |
| 49 Creative details | Charge poses, delayed branches, secondary dust, embers/debris/body follow-through/clouds/scorch/subtle screen response | authored action timing, fracture delays, body history, camera feedback, transient aftermath | IMPLEMENTED / RUNTIME-PENDING |
| 50 Prohibitions | No plan-only output, pseudocode-only, flat crack spam, scaled Steve/static dragon, hardcoded input, fake build/JAR, ripped assets | concrete source/assets and strict release audit; no artifact is labelled release until Gradle passes | IMPLEMENTED / BUILD-PENDING |
| 51 Research | Whitebeard/Gura and Kaido/Seiryu canon-informed moves; canon-compatible Minecraft reinterpretation | ability names/roles preserved; no commercial assets embedded | IMPLEMENTED |
| 52 Experience test | Mechanics remain differentiated without particles; visuals remain authored beyond damage numbers | defensive repulsion, mobility, scale defense, barrage, flight/body rush, vortex etc. are mechanically distinct | IMPLEMENTED / RUNTIME-PENDING |
| 53 Final polish | Animation transitions, origins, clipping, camera/HUD/audio/VFX/debris/turning/pacing/bounds/load/repetition | static source pass completed; visual/runtime polish cannot be honestly closed without running Minecraft | RUNTIME-PENDING |
| 54 Final response | JAR + target/deps/content/controls/install/build command/SHA-256/real limitations | workflow generates jar + checksum evidence; final report must use observed results only | BUILD-PENDING |
| 55 Final directive | Finish, build, test, return working JAR | release remains blocked until an environment can execute JDK25/Gradle/Fabric runtime | BUILD-PENDING |

## Mandatory in-game verification matrix

The following checks are intentionally **not** marked complete by source inspection. A release build must run these against a clean 26.3 Fabric 0.19.5 instance and record failures/fixes before the final JAR is handed off.

- Client reaches title/world without missing dependency/resource/mixin/classloading errors; dedicated server reaches ready state without client-class crashes.
- Both fruits appear, render correctly, consume correctly, reject a second fruit, apply disorientation, unlock only their own HUD/abilities, and persist across save/relog/dimension change.
- All five mappings appear under Controls, rebind, survive restart, and do not fire while GUI/chat consumes input.
- Gura 1–5: first-person pose, third-person observer pose, VFX origin/alignment, damage/knockback/cooldown, actual terrain edit, disabled-grief visual fallback, water/block-entity/unbreakable edges, repeated-use stability.
- Seiryu Human: passive entity/block claw, four base techniques, Hybrid transition and reverse transition.
- Hybrid: silhouette/hitboxes/camera/locomotion, all four replacement moves, compact breath, Dragon transition and reverse transition.
- Full Dragon: articulated body turning, flight acceleration/vertical control/flame clouds/camera collision, held-M1 heat/energy loop, all five Dragon abilities, death/dimension/logout cleanup.
- Multiplayer with at least two clients: observer sees transformations/poses/VFX; server controls damage/destruction/cooldowns; friendly-fire setting is respected; packet spam cannot bypass gates; reconnect does not duplicate rigs/effects.
- Performance on LOW/MEDIUM/HIGH/CINEMATIC: no uncontrolled display/debris counts; destruction queue remains bounded; ultimates do not freeze the server; distant VFX/camera response remains tolerable.
- Final dedicated polish pass: clipping, mouth/hand origins, camera offsets, UI spacing, audio levels, effect lifetimes, body follow-through, transformation pacing, impact timing, destruction boundaries, visual repetition.
