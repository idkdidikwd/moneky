#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path
from PIL import Image, ImageStat

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
RES = SRC / "main" / "resources"
ASSETS = RES / "assets" / "grandlinequakes"

failures: list[str] = []
passes: list[str] = []


def ok(name: str, cond: bool, detail: str = "") -> None:
    (passes if cond else failures).append(name + (f" — {detail}" if detail else ""))


def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")


def contains(path: str, *needles: str) -> bool:
    s = text(path)
    return all(n in s for n in needles)


def regex(path: str, pattern: str) -> bool:
    return re.search(pattern, text(path), re.S | re.M) is not None

# 1. Exact target/build metadata.
props = {}
for line in text("gradle.properties").splitlines():
    if "=" in line and not line.lstrip().startswith("#"):
        k, v = line.split("=", 1)
        props[k.strip()] = v.strip()
ok("Minecraft target is exactly 26.3", props.get("minecraft_version") == "26.3")
ok("Fabric Loader target is exactly 0.19.5", props.get("loader_version") == "0.19.5")
ok("Fabric API target is 0.161.0+26.3", props.get("fabric_api_version") == "0.161.0+26.3")
ok("Loom is pinned to stable 1.17.21", props.get("loom_version") == "1.17.21")
ok("Java release is 25", contains("build.gradle", "options.release = 25", "JavaVersion.VERSION_25"))
ok("Split client/common source sets", contains("build.gradle", "splitEnvironmentSourceSets()", "sourceSets.client"))

# 2. Resource metadata parses and is target-locked.
try:
    fm = json.loads(text("src/main/resources/fabric.mod.json").replace('${version}', '1.0.0'))
    ok("fabric.mod.json parses", True)
    ok("fabric.mod.json pins Minecraft 26.3", fm.get("depends", {}).get("minecraft") == "=26.3")
    ok("fabric.mod.json requires Java 25", fm.get("depends", {}).get("java") == ">=25")
    ok("Client entrypoint isolated", "client" in fm.get("entrypoints", {}) and fm.get("environment") == "*")
except Exception as e:
    ok("fabric.mod.json parses", False, str(e))

for j in RES.rglob("*.json"):
    if j.name == "fabric.mod.json":
        continue
    try:
        json.loads(j.read_text(encoding="utf-8"))
        ok(f"JSON parses: {j.relative_to(ROOT)}", True)
    except Exception as e:
        ok(f"JSON parses: {j.relative_to(ROOT)}", False, str(e))

# 3. Acquisition, ownership, persistence and one-fruit rule.
ok("Both Devil Fruit items registered", contains("src/main/java/dev/openai/grandline/registry/ModItems.java", "GURA_GURA_NO_MI", "UO_UO_NO_MI_SEIRYU", "DevilFruitItem"))
ok("Fruit power required before ability use", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "if(fruit==FruitPower.NONE", "tryActivate"))
ok("One-fruit ownership enforced", contains("src/main/java/dev/openai/grandline/item/DevilFruitItem.java", "already_bound", "FruitPower.NONE"))
ok("Fruit consumption has authored sequence", contains("src/main/java/dev/openai/grandline/item/DevilFruitItem.java", "onUseTick", "finishUsingItem", "NAUSEA", "FRUIT_AWAKEN"))
ok("Fruit state is persistent and synced", contains("src/main/java/dev/openai/grandline/state/PowerState.java", ".persistent(Codec.INT)", ".syncWith(ByteBufCodecs.INT", "copyOnDeath"))
ok("Form/cooldown/energy state is server-owned", contains("src/main/java/dev/openai/grandline/state/PowerState.java", "FORM", "ENERGY", "COOLDOWNS", "ACTION_TICKS"))

# 4. HUD and input.
ok("Five configurable key mappings", text("src/client/java/dev/openai/grandline/client/ModKeyMappings.java").count('key("ability_') == 5)
ok("Key mappings use Minecraft/Fabric registry", contains("src/client/java/dev/openai/grandline/client/ModKeyMappings.java", "KeyMappingHelper.registerKeyMapping", "InputConstants.Type.KEYSYM"))
ok("Ability/Dragon input is gated from screens and overlays", contains("src/client/java/dev/openai/grandline/client/ModKeyMappings.java", "client.gui.screen() == null && client.gui.overlay() == null", "if (gameplay && PowerState.fruit"))
ok("HUD is bottom-right and five-slot", contains("src/client/java/dev/openai/grandline/client/AbilityHud.java", "g.guiWidth() - totalW", "for (int slot = 1; slot <= 5; slot++)"))
ok("HUD shows cooldown/ready/charging/low-energy", contains("src/client/java/dev/openai/grandline/client/AbilityHud.java", "CHARGE", "READY", "LOW", "cooldownEnd"))
ok("HUD changes by Seiryu form", contains("src/client/java/dev/openai/grandline/client/AbilityHud.java", "SEIRYU — HUMAN", "SEIRYU — HYBRID", "SEIRYU — FULL DRAGON"))

# 5. Server validation and multiplayer architecture.
ok("Ability packets are serverbound and validated server-side", contains("src/main/java/dev/openai/grandline/network/ModNetworking.java", "serverboundPlay", "registerGlobalReceiver", "tryActivate"))
ok("Cooldown and energy validated server-side", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "cooldownEnd", "no_energy", "setCooldownEnd"))
ok("Remote-visible transformation state", contains("src/main/java/dev/openai/grandline/state/PowerState.java", "syncWith", "FORM"))
ok("Reconnect cleans stale transformation rigs", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "ServerPlayConnectionEvents.JOIN", "TransformationRigManager.clearAll"))
ok("Respawn resets transient form safely", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "AFTER_RESPAWN", "DragonForm.HUMAN"))
ok("Dimension change cancels stale world-bound cinematics", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "AFTER_PLAYER_CHANGE_LEVEL", "CinematicScheduler.cancel", "PowerState.setAction(player, 0, 0)"))
ok("Disconnect/respawn transient VFX ownership is cleaned", contains("src/main/java/dev/openai/grandline/visual/DisplayFx.java", "glq_fx_owner_", "clearOwner") and contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "DisplayFx.clearOwner"))
ok("Ability cinematics are owner-scoped", contains("src/main/java/dev/openai/grandline/ability/CinematicScheduler.java", "schedule(ServerPlayer owner", "cancel(UUID owner)") and contains("src/main/java/dev/openai/grandline/ability/GuraAbilities.java", "CinematicScheduler.schedule(p,") and contains("src/main/java/dev/openai/grandline/ability/SeiryuAbilities.java", "CinematicScheduler.schedule(p,"))
ok("Transient display cleanup is owner-scoped", contains("src/main/java/dev/openai/grandline/visual/DisplayFx.java", "CinematicScheduler.schedule(player, lifetime"))
ok("VFX command failures are rate-limited and logged", contains("src/main/java/dev/openai/grandline/world/CommandUtil.java", "FAILURES.incrementAndGet()", "LOGGER.warn"))
ok("Server stop clears static cross-world state", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "SERVER_STOPPING", "CinematicScheduler.clear()", "DestructionManager.clear()", "DragonController.clearState()"))
ok("Logout/dimension/respawn cancel queued player destruction", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "cancelSource(UUID sourceId)") and text("src/main/java/dev/openai/grandline/ability/AbilityEngine.java").count("DestructionManager.cancelSource") >= 4)

# 6. Gura signature systems and five distinct moves.
gura = text("src/main/java/dev/openai/grandline/ability/GuraAbilities.java")
for name in ["hypocenter", "airBreak", "seaquake", "repulsion", "worldShaker"]:
    ok(f"Gura implementation: {name}", re.search(rf"\b{name}\s*\(", gura) is not None)
ok("Gura has layered quake sphere", contains("src/main/java/dev/openai/grandline/ability/GuraAbilities.java", "pressureShell", "Microfractures", "glq_hypo_shell"))
ok("Gura has world-space fractures", contains("src/main/java/dev/openai/grandline/visual/FractureFx.java", "fracture", "DisplayFx"))
ok("Gura terrain rupture uses staged destruction", contains("src/main/java/dev/openai/grandline/ability/GuraAbilities.java", "DestructionManager", "schedule"))
ok("World Shaker includes staged aftershocks", contains("src/main/java/dev/openai/grandline/ability/GuraAbilities.java", "worldShaker", "aftershock"))

# 7. Destruction safety/performance.
ok("Destruction can be disabled/configured", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "terrainDestruction", "maxDestructionRadius"))
ok("Destruction is staged", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "blocksPerTick", "maxQueuedBlocks"))
ok("Destruction avoids block entities", regex("src/main/java/dev/openai/grandline/world/DestructionManager.java", r"getBlockEntity|hasBlockEntity"))
ok("Destruction avoids unloaded chunks", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "hasChunkAt"))
ok("Destruction respects unbreakable blocks", regex("src/main/java/dev/openai/grandline/world/DestructionManager.java", r"destroySpeed|BlockState|isAir"))
ok("Destruction guards against falling-block entity cascades", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "instanceof FallingBlock", "FallingBlockEntity"))
ok("Destruction exposes protection/claim compatibility event", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "DestructionProtectionCallback.EVENT") and contains("src/main/java/dev/openai/grandline/api/DestructionProtectionCallback.java", "EventFactory.createArrayBacked"))
ok("Persistent ignition uses protection/claim veto", contains("src/main/java/dev/openai/grandline/world/WorldOps.java", "igniteSurface", "DestructionProtectionCallback.EVENT.invoker().allow"))
ok("Visual debris is separate from world edits", contains("src/main/java/dev/openai/grandline/world/DestructionManager.java", "Visual destruction is deliberately handled elsewhere"))
ok("Seismic defense intercepts incoming rather than every projectile", contains("src/main/java/dev/openai/grandline/world/WorldOps.java", "projectile.getOwner() == source", "velocity.dot(toUser.normalize()) > 0.05"))

# 8. Seiryu base, Hybrid, Dragon and M1.
seiryu = text("src/main/java/dev/openai/grandline/ability/SeiryuAbilities.java")
for name in ["azureClaw", "scaleBastion", "cloudStep", "dragonPulse", "transformHybrid",
             "thunderBagua", "kundali", "hybridBreath", "vajra", "transformDragon",
             "dragonRush", "kaifu", "tatsumaki", "tatsumakiKaifu", "flameDragon"]:
    ok(f"Seiryu implementation: {name}", re.search(rf"\b{name}\s*\(", seiryu) is not None)
ok("Base passive claw on entities", contains("src/main/java/dev/openai/grandline/ability/AbilityEngine.java", "passiveClaw(sp)"))
ok("Base passive claw has struck-block material debris", contains("src/main/java/dev/openai/grandline/ability/SeiryuAbilities.java", "BlockParticleOption", "passiveClawBlock"))
ok("Hybrid and Dragon are real custom rigs", contains("src/main/java/dev/openai/grandline/visual/TransformationRigManager.java", "tickHybrid", "tickDragon", "body_", "tail_"))
ok("Dragon rig has articulated jaw", contains("src/main/java/dev/openai/grandline/visual/TransformationRigManager.java", '"jaw"', "jawPitch"))
ok("Dragon flight has momentum and flame clouds", contains("src/main/java/dev/openai/grandline/world/DragonController.java", "Heavy momentum", "velocity") and contains("src/main/java/dev/openai/grandline/visual/TransformationRigManager.java", "Flame Clouds", "minecraft:cloud"))
ok("Held M1 Dragon breath", contains("src/main/java/dev/openai/grandline/world/DragonController.java", "ATTACK", "breath", "igniteCone"))
ok("Dragon breath ignites/scorches terrain", contains("src/main/java/dev/openai/grandline/world/DragonController.java", "igniteSurface"))
ok("Form reversal/cleanup available", contains("src/main/java/dev/openai/grandline/ability/SeiryuAbilities.java", "revertForm"))

# 9. Animation/camera.
ok("First-person authored poses exist", contains("src/client/java/dev/openai/grandline/mixin/FirstPersonHandsMixin.java", "submitArmWithItem", "DevilFruitItem", "action"))
ok("Third-person authored poses exist", contains("src/client/java/dev/openai/grandline/mixin/PlayerModelMixin.java", "authoredPose", "action"))
ok("Hybrid/Dragon camera adaptation", contains("src/client/java/dev/openai/grandline/mixin/CameraMixin.java", "DragonForm.HUMAN", "DragonForm.DRAGON", "dragonCameraDistance"))
ok("Camera shake is configurable", contains("src/client/java/dev/openai/grandline/mixin/CameraMixin.java", "cameraShake") and contains("src/main/java/dev/openai/grandline/config/ModConfig.java", "cameraShake"))
ok("Dragon movement animates body follow-through", contains("src/main/java/dev/openai/grandline/visual/TransformationRigManager.java", "lateral", "spineOrigin", "body_"))

# 10. Config coverage.
config = text("src/main/java/dev/openai/grandline/config/ModConfig.java")
for key in ["terrainDestruction", "maxDestructionRadius", "vfxQuality", "cameraShake", "dragonCameraDistance", "friendlyFire", "cooldownMultiplier"]:
    ok(f"Config: {key}", key in config)
ok("VFX quality tiers Low/Medium/High/Cinematic", all(x in config for x in ["LOW", "MEDIUM", "HIGH", "CINEMATIC"]))

# 11. Asset checks: all icons/fruits exist, are nonblank, sound files decode.
required_images = [
    ASSETS / "textures/item/gura_gura_no_mi.png",
    ASSETS / "textures/item/uo_uo_no_mi_seiryu.png",
] + [ASSETS / f"textures/gui/abilities/{family}_{slot}.png" for family in ("gura", "base", "hybrid", "dragon") for slot in range(1,6)]
for img_path in required_images:
    rel = img_path.relative_to(ROOT)
    if not img_path.exists():
        ok(f"Image exists: {rel}", False)
        continue
    try:
        im = Image.open(img_path).convert("RGBA")
        stat = ImageStat.Stat(im)
        alpha_extrema = im.getchannel("A").getextrema()
        nonblank = alpha_extrema[1] > 0 and len(im.getcolors(maxcolors=1_000_000) or []) > 1
        ok(f"Image nonblank: {rel}", nonblank, f"{im.width}x{im.height}")
    except Exception as e:
        ok(f"Image decodes: {rel}", False, str(e))

sound_json = json.loads((ASSETS / "sounds.json").read_text(encoding="utf-8"))
for ogg in sorted((ASSETS / "sounds").glob("*.ogg")):
    proc = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nk=1:nw=1", str(ogg)], capture_output=True, text=True)
    duration = 0.0
    try: duration = float(proc.stdout.strip())
    except Exception: pass
    ok(f"Sound decodes: {ogg.name}", proc.returncode == 0 and duration > 0.03, f"{duration:.2f}s")
ok("sounds.json has distinct sound events", len(sound_json) >= 10)

# 12. Release hygiene.
java_files = list(SRC.rglob("*.java"))
forbidden = re.compile(r"\b(TODO|FIXME|PLACEHOLDER)\b", re.I)
hits=[]
for p in java_files:
    for i,line in enumerate(p.read_text(encoding="utf-8").splitlines(),1):
        if forbidden.search(line): hits.append(f"{p.relative_to(ROOT)}:{i}")
ok("No TODO/FIXME/placeholder markers in Java", not hits, ", ".join(hits[:5]))
ok("No debug System.out/printStackTrace", not any(("System.out" in p.read_text(encoding="utf-8") or "printStackTrace" in p.read_text(encoding="utf-8")) for p in java_files))
ok("License bundled", (ROOT / "LICENSE").exists())
ok("Release CI provisions JDK 25 and Gradle 9.6.0", contains(".github/workflows/release-build.yml", "java-version: '25'", "gradle-version: '9.6.0'", "clean build"))
ok("Release CI smoke-tests dedicated server", contains(".github/workflows/release-build.yml", "Dedicated-server startup smoke test", "runServer", "server-smoke.log"))
ok("Release CI verifies JAR and SHA-256", contains(".github/workflows/release-build.yml", "sha256sum", "built-fabric.mod.json", "upload-artifact@v4"))
ok("Master brief traceability ledger exists", (ROOT / "docs/REQUIREMENTS_MATRIX.md").exists())

# Produce compact report.
print(f"Static release audit: {len(passes)} passed, {len(failures)} failed")
for f in failures:
    print("FAIL:", f)
if failures:
    sys.exit(1)
print("All static release gates passed. This does NOT substitute for a real Gradle/Fabric compile and game runtime test.")
