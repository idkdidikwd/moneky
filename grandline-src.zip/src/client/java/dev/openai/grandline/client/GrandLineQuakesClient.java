package dev.openai.grandline.client;

import net.fabricmc.api.ClientModInitializer;

public final class GrandLineQuakesClient implements ClientModInitializer {
    @Override
    public void onInitializeClient(){
        ModKeyMappings.initialize();
        AbilityHud.initialize();
    }
}
