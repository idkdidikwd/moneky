package dev.openai.grandline.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.openai.grandline.GrandLineQuakes;
import dev.openai.grandline.network.AbilityPayload;
import dev.openai.grandline.network.ControlPayload;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.world.DragonController;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;

public final class ModKeyMappings {
    private static final KeyMapping.Category CATEGORY = KeyMapping.Category.register(GrandLineQuakes.id("abilities"));
    public static final KeyMapping[] ABILITIES = {
            key("ability_1", InputConstants.KEY_Z),
            key("ability_2", InputConstants.KEY_X),
            key("ability_3", InputConstants.KEY_C),
            key("ability_4", InputConstants.KEY_V),
            key("ability_5", InputConstants.KEY_B)
    };
    private static int lastFlags = -1;
    private static int controlTicker;

    private ModKeyMappings() {}

    private static KeyMapping key(String name, int code) {
        return KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.grandlinequakes." + name, InputConstants.Type.KEYSYM, code, CATEGORY));
    }

    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            boolean gameplay = client.gui.screen() == null && client.gui.overlay() == null;
            // Always drain queued presses. This prevents an ability key tapped while chat, inventory,
            // controls, or another GUI is open from being replayed as soon as the screen closes.
            for (int i = 0; i < ABILITIES.length; i++) {
                while (ABILITIES[i].consumeClick()) {
                    if (gameplay) ClientPlayNetworking.send(new AbilityPayload(i + 1));
                }
            }

            int flags = 0;
            if (gameplay && PowerState.fruit(client.player) == FruitPower.SEIRYU && PowerState.form(client.player) == DragonForm.DRAGON) {
                if (client.options.keyUp.isDown()) flags |= DragonController.FORWARD;
                if (client.options.keyDown.isDown()) flags |= DragonController.BACK;
                if (client.options.keyLeft.isDown()) flags |= DragonController.LEFT;
                if (client.options.keyRight.isDown()) flags |= DragonController.RIGHT;
                if (client.options.keyJump.isDown()) flags |= DragonController.UP;
                if (client.options.keyShift.isDown()) flags |= DragonController.DOWN;
                if (gameplay && client.options.keyAttack.isDown()) flags |= DragonController.ATTACK;
            }
            controlTicker++;
            if (flags != lastFlags || controlTicker % 3 == 0) {
                ClientPlayNetworking.send(new ControlPayload(flags));
                lastFlags = flags;
            }
        });
    }
}
