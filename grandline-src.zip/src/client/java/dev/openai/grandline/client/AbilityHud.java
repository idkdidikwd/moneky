package dev.openai.grandline.client;

import dev.openai.grandline.GrandLineQuakes;
import dev.openai.grandline.ability.AbilityCatalog;
import dev.openai.grandline.ability.AbilityDefinition;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;
import dev.openai.grandline.state.PowerState;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.Locale;

public final class AbilityHud {
    private AbilityHud() {}

    public static void initialize() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT, GrandLineQuakes.id("ability_hud"), AbilityHud::extract);
    }

    private static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        FruitPower fruit = PowerState.fruit(mc.player);
        if (fruit == FruitPower.NONE) return;
        DragonForm form = PowerState.form(mc.player);

        // Fit all five slots even at small GUI scales/resolutions. Normal layout keeps the
        // spacious 46 px cards; compact layout tightens pitch/card widths without hiding slots.
        boolean compact = g.guiWidth() < 300;
        int cardW = compact ? 40 : 46;
        int pitch = compact ? 42 : 50;
        int totalW = pitch * 4 + cardW;
        int x = Math.max(4, g.guiWidth() - totalW - 10);
        int y = Math.max(8, g.guiHeight() - 112);
        int accent = fruit == FruitPower.GURA ? 0xFFD9F5FF
                : form == DragonForm.DRAGON ? 0xFF50D9FF
                : form == DragonForm.HYBRID ? 0xFFE34A62 : 0xFF4FC4E8;

        g.fill(x - 6, y - 18, x + totalW + 5, y + 58, 0xB810151D);
        g.outline(x - 6, y - 18, totalW + 11, 76, 0xCC000000 | accent & 0x00FFFFFF);
        String title = fruit == FruitPower.GURA ? "GURA GURA NO MI"
                : form == DragonForm.HUMAN ? "SEIRYU — HUMAN"
                : form == DragonForm.HYBRID ? "SEIRYU — HYBRID" : "SEIRYU — FULL DRAGON";
        g.text(mc.font, title, x, y - 15, 0xFFF4FAFF, true);
        int energy = PowerState.energy(mc.player);
        int energyW = compact ? 62 : 76;
        int energyX = x + totalW - energyW;
        g.text(mc.font, compact ? ("E " + energy) : ("ENERGY " + energy), energyX, y - 15, accent, true);
        g.fill(energyX, y - 5, energyX + energyW, y - 2, 0xAA24303C);
        g.fill(energyX, y - 5, energyX + Math.round(energyW * energy / 100.0f), y - 2, accent);
        if (fruit == FruitPower.SEIRYU && form == DragonForm.DRAGON) {
            g.text(mc.font, "HOLD M1 • BREATH", x, y - 6, 0xFFFFA069, false);
        }

        long now = mc.player.level().getGameTime();
        int action = PowerState.action(mc.player);
        int activeSlot = action == 0 ? 0 : Math.floorMod(action, 100);
        for (int slot = 1; slot <= 5; slot++) {
            AbilityDefinition a = AbilityCatalog.get(fruit, form, slot);
            if (a == null) continue;
            int sx = x + (slot - 1) * pitch;
            long remain = Math.max(0, PowerState.cooldownEnd(mc.player, slot) - now);
            int actionTicks = PowerState.actionTicks(mc.player);
            boolean active = activeSlot == slot && actionTicks > 0;
            boolean charging = active && isCharging(action, actionTicks);
            boolean energyOk = PowerState.energy(mc.player) >= a.energyCost();
            boolean ready = remain == 0 && energyOk && PowerState.actionTicks(mc.player) <= 0;

            g.fill(sx, y, sx + cardW, y + 51, ready ? 0xDB1A2A36 : 0xDB11161D);
            g.outline(sx, y, cardW, 51, active ? 0xFFFFFFFF : ready ? a.accentColor() : 0xFF4B4F55);
            g.blit(RenderPipelines.GUI_TEXTURED, icon(fruit, form, slot), sx + 3, y + 3,
                    0.0f, 0.0f, 20, 20, 32, 32);

            if (remain > 0) {
                int h = (int)Math.min(49, Math.ceil(49.0 * remain / Math.max(1, a.cooldownTicks())));
                g.fill(sx + 1, y + 50 - h, sx + cardW - 1, y + 50, 0x99000000);
            }
            if (active) {
                g.fill(sx + 2, y + 2, sx + cardW - 2, y + 5, a.accentColor());
            }

            String key = ModKeyMappings.ABILITIES[slot - 1].getTranslatedKeyMessage().getString();
            g.text(mc.font, trim(key, compact ? 4 : 5), sx + cardW - (compact ? 15 : 18), y + 4, 0xFFF0F5FA, true);
            g.text(mc.font, trim(a.shortName(), compact ? 8 : 10), sx + 3, y + 26, 0xFFFFFFFF, false);
            String state = active ? activeState(fruit, form, slot, PowerState.actionTicks(mc.player))
                    : remain > 0 ? String.format(Locale.ROOT, "%.1fs", remain / 20.0)
                    : !energyOk ? "LOW" : ready ? "READY" : "LOCK";
            int stateColor = (active || charging) ? a.accentColor() : remain > 0 ? 0xFFFFC7C7 : ready ? 0xFFB9FFD4 : 0xFFFFDA85;
            g.text(mc.font, state, sx + 3, y + 40, stateColor, false);
        }
    }

    private static boolean isCharging(int action, int ticks) {
        return switch (action) {
            case 101 -> ticks > 8;   // Hypocenter winds up before release.
            case 102 -> ticks > 25;  // crack formation precedes travelling shock front
            case 105 -> ticks > 60;  // World Shaker grab/startup
            case 205 -> ticks > 16;  // Human -> Hybrid transformation
            case 303 -> ticks > 21;  // Hybrid mouth-fire buildup
            case 305 -> ticks > 26;  // Hybrid -> Full Dragon atmosphere buildup
            case 405 -> ticks > 62;  // Kaen Daiko fiery mantle forms before the charge
            case 505 -> ticks > 6;   // controlled reverse transformation
            default -> false;
        };
    }

    private static Identifier icon(FruitPower fruit, DragonForm form, int slot) {
        String family = fruit == FruitPower.GURA ? "gura"
                : form == DragonForm.HYBRID ? "hybrid"
                : form == DragonForm.DRAGON ? "dragon" : "base";
        return GrandLineQuakes.id("textures/gui/abilities/" + family + "_" + slot + ".png");
    }

    private static String activeState(FruitPower fruit, DragonForm form, int slot, int ticks) {
        if (fruit == FruitPower.GURA) {
            if (slot == 1) return ticks > 10 ? "CHARGE" : "RELEASE";
            if (slot == 2) return ticks > 12 ? "FRACTURE" : "SHOCK";
            if (slot == 5) return ticks > 34 ? "SEIZE" : "SHAKE";
            return "ACTIVE";
        }
        if (slot == 5) {
            if (form == DragonForm.HUMAN) return "HYBRID";
            if (form == DragonForm.HYBRID) return "ASCEND";
            return ticks > 55 ? "MANTLE" : "CHARGE";
        }
        if (form == DragonForm.HYBRID && slot == 3) return ticks > 10 ? "IGNITE" : "BREATH";
        return "ACTIVE";
    }

    private static String trim(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n - 1) + "…";
    }
}
