package dev.openai.grandline.mixin;

import dev.openai.grandline.item.DevilFruitItem;
import dev.openai.grandline.state.PowerState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Authored third-person poses for human-form techniques and Devil Fruit consumption. The render
 * state carries the entity id, so remote players receive the same synchronized action pose without
 * client-owned combat state.
 */
@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin extends HumanoidModel<AvatarRenderState> {
    protected PlayerModelMixin(ModelPart root) {
        super(root);
    }

    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V", at = @At("TAIL"))
    private void grandlinequakes$authoredPose(AvatarRenderState state, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity entity = mc.level.getEntity(state.id);
        if (!(entity instanceof Player player)) return;

        if (player.isUsingItem() && player.getUseItem().getItem() instanceof DevilFruitItem) {
            float t = player.getUseItemRemainingTicks();
            float chew = (float)Math.sin((player.tickCount + t) * 0.58f);
            this.head.xRot += -0.17f + chew * 0.035f;
            this.head.yRot += chew * 0.055f;
            this.rightArm.xRot = -1.80f + chew * 0.09f;
            this.rightArm.yRot = -0.28f;
            this.rightArm.zRot = 0.08f + chew * 0.035f;
            this.leftArm.xRot = -0.72f - chew * 0.06f;
            this.leftArm.yRot = 0.34f;
            this.body.yRot = chew * 0.035f;
            return;
        }

        int action = PowerState.action(player);
        int ticks = PowerState.actionTicks(player);
        if (action == 0 || ticks <= 0) return;
        float pulse = (float)Math.sin((player.tickCount + state.ageInTicks * 0.05f) * 0.34f);
        int family = action / 100;
        int slot = Math.floorMod(action, 100);

        if (family == 1) { // Gura: every move has a different readable silhouette.
            switch (slot) {
                case 1 -> { // quake fist: shoulder coils, then punches through centerline
                    float release = ticks < 10 ? 1.0f : Math.max(0f, 1f - (ticks - 10) / 18f);
                    this.rightArm.xRot = -1.45f - 1.25f * release;
                    this.rightArm.yRot = -0.38f + 0.32f * release;
                    this.body.yRot = -0.30f + 0.44f * release;
                    this.leftArm.xRot = -0.42f;
                }
                case 2 -> { // air break: two-handed spatial tear
                    this.rightArm.xRot = -1.42f; this.leftArm.xRot = -1.42f;
                    this.rightArm.yRot = -0.62f; this.leftArm.yRot = 0.62f;
                    this.rightArm.zRot = -0.22f; this.leftArm.zRot = 0.22f;
                    this.body.xRot = 0.08f;
                }
                case 3 -> { // ground rupture: overhead-to-ground transmission stance
                    this.rightArm.xRot = -2.70f + pulse * .05f;
                    this.leftArm.xRot = -2.32f - pulse * .05f;
                    this.body.xRot = 0.42f;
                    this.head.xRot -= 0.24f;
                }
                case 4 -> { // repulsion: planted radial guard
                    this.rightArm.xRot = -1.16f; this.leftArm.xRot = -1.16f;
                    this.rightArm.yRot = -0.92f; this.leftArm.yRot = 0.92f;
                    this.rightArm.zRot = -0.72f; this.leftArm.zRot = 0.72f;
                    this.body.xRot = -0.08f;
                }
                case 5 -> { // world shaker: seize the air/world with a wide locked stance
                    this.rightArm.xRot = -1.48f; this.leftArm.xRot = -1.48f;
                    this.rightArm.yRot = -1.05f; this.leftArm.yRot = 1.05f;
                    this.rightArm.zRot = -0.38f - pulse*.05f; this.leftArm.zRot = 0.38f + pulse*.05f;
                    this.body.xRot = -0.14f;
                    this.head.xRot += 0.12f;
                }
            }
        } else if (family == 2) { // Seiryu human/base moves and Hybrid transformation.
            switch (slot) {
                case 1 -> { // claw sweep
                    this.rightArm.xRot = -1.72f; this.rightArm.yRot = -0.72f; this.rightArm.zRot = -0.20f;
                    this.body.yRot = 0.42f;
                }
                case 2 -> { // scale reinforcement / guarded shell
                    this.rightArm.xRot = -0.96f; this.leftArm.xRot = -0.96f;
                    this.rightArm.yRot = -0.55f; this.leftArm.yRot = 0.55f;
                }
                case 3 -> { // flame cloud step: forward aerodynamic pose
                    this.rightArm.xRot = 0.48f; this.leftArm.xRot = 0.48f;
                    this.body.xRot = 0.26f;
                }
                case 4 -> { // dragon pulse / roar
                    this.rightArm.xRot = -0.62f; this.leftArm.xRot = -0.62f;
                    this.rightArm.zRot = -0.86f; this.leftArm.zRot = 0.86f;
                    this.head.xRot -= 0.22f;
                }
                case 5 -> { // Hybrid transformation: expanding, trembling silhouette
                    this.rightArm.xRot = -0.48f; this.leftArm.xRot = -0.48f;
                    this.rightArm.zRot = -1.02f - pulse*.08f; this.leftArm.zRot = 1.02f + pulse*.08f;
                    this.body.xRot = -0.11f + pulse*.025f;
                    this.head.xRot = -0.22f;
                    this.rightLeg.xRot = 0.16f; this.leftLeg.xRot = -0.16f;
                }
            }
        }
    }
}
