package dev.openai.grandline.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.PowerState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the vanilla player silhouette client-side while a Seiryu transformation rig is active.
 * The server-side Player remains fully visible to AI/gameplay systems and continues to own health,
 * physics and networking; only its vanilla render submission is suppressed for observers.
 */
@Mixin(AvatarRenderer.class)
public abstract class AvatarRendererMixin {
    @Inject(
            method = "submit(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
            at = @At("HEAD"), cancellable = true)
    private void grandlinequakes$replaceTransformedAvatar(AvatarRenderState state, PoseStack poseStack,
                                                          SubmitNodeCollector collector, CameraRenderState camera,
                                                          CallbackInfo ci) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null) return;
        Entity entity=mc.level.getEntity(state.id);
        if(entity instanceof Player player && PowerState.form(player)!=DragonForm.HUMAN) {
            ci.cancel();
        }
    }
}
