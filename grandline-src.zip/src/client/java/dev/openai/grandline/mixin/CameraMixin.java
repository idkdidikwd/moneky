package dev.openai.grandline.mixin;

import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;
import dev.openai.grandline.state.PowerState;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow private boolean detached;
    @Shadow private Entity entity;
    @Shadow private float roll;
    @Shadow protected abstract void move(float forwards, float up, float right);

    @Inject(method = "alignWithEntity", at = @At("TAIL"))
    private void grandlinequakes$transformAndImpactCamera(float partialTicks, CallbackInfo ci) {
        Minecraft mc = Minecraft.getInstance();
        if (!(entity instanceof Player local) || mc.player != local) return;

        // Form-aware framing is local-only. It changes the camera, never gameplay authority.
        if (PowerState.fruit(local) == FruitPower.SEIRYU) {
            DragonForm form = PowerState.form(local);
            if (form != DragonForm.HUMAN) {
                if (detached) {
                    float desiredExtra = form == DragonForm.DRAGON
                            ? (float)Math.max(0.0, ModConfig.dragonCameraDistance - 4.0)
                            : 2.25f;
                    float collisionSafeExtra = ((CameraInvoker)(Object)this).grandlinequakes$getMaxZoom(desiredExtra);
                    move(-collisionSafeExtra, form == DragonForm.DRAGON ? 1.65f : 0.45f, 0.0f);
                } else if (form == DragonForm.DRAGON) {
                    // Put first-person at the dragon's head instead of inside the hidden human body.
                    move(3.05f, 1.55f, 0.0f);
                } else {
                    move(0.25f, 0.32f, 0.0f);
                }
            }
        }

        // Distance-scaled impact shake observes synchronized actions from every nearby player.
        // This makes a spectator feel a World Shaker or transformation without giving a remote
        // attack the same force as the user standing at its hypocenter.
        if (mc.level == null || ModConfig.cameraShake <= 0.0) return;
        double best = 0.0;
        int bestAction = 0;
        int bestTicks = 0;
        for (Player source : mc.level.players()) {
            int action = PowerState.action(source);
            int ticks = PowerState.actionTicks(source);
            if (action == 0 || ticks <= 0) continue;
            double distance = source.position().distanceTo(local.position());
            double reach = action % 100 == 5 ? 92.0 : action / 100 == 1 ? 54.0 : 42.0;
            if (distance > reach) continue;
            double base = action % 100 == 5 ? 1.0 : action / 100 == 1 ? 0.72 : 0.56;
            double distanceFalloff = 1.0 - Math.min(1.0, distance / reach);
            double strength = base * distanceFalloff * distanceFalloff;
            if (source == local) strength = Math.max(strength, base * 0.92);
            if (strength > best) {
                best = strength;
                bestAction = action;
                bestTicks = ticks;
            }
        }
        if (best <= 0.0) return;

        double fade = Math.min(1.0, bestTicks / 12.0);
        double phase = (local.tickCount + partialTicks) * 2.65 + bestAction * 0.37;
        float amp = (float)(0.080 * best * fade * ModConfig.cameraShake);
        move((float)Math.sin(phase * .83) * amp * .20f,
                (float)Math.sin(phase * 1.37) * amp,
                (float)Math.cos(phase) * amp);

        // World Shaker sells battlefield displacement with a tiny, distance-scaled horizon cant
        // rather than rotating the level. It is deliberately restrained and tied to the same
        // accessibility intensity as camera shake.
        if (bestAction == 105) {
            float seizeEnvelope = (float)Math.min(1.0, bestTicks / 20.0);
            float cant = (float)Math.sin((local.tickCount + partialTicks) * .105f)
                    * (float)(2.35 * best * seizeEnvelope * ModConfig.cameraShake);
            roll += cant;
        }
    }

    @Inject(method = "calculateFov", at = @At("RETURN"), cancellable = true)
    private void grandlinequakes$fovKick(float partialTicks, CallbackInfoReturnable<Float> cir) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || entity != mc.player || ModConfig.cameraShake <= 0.0) return;
        int action = PowerState.action(mc.player);
        int ticks = PowerState.actionTicks(mc.player);
        if (action == 0 || ticks <= 0) return;
        float kick = switch (action % 100) {
            case 1 -> 2.8f;
            case 3 -> 3.6f;
            case 5 -> 5.2f;
            default -> 1.8f;
        };
        if (PowerState.form(mc.player) == DragonForm.DRAGON) kick += 1.4f;
        float envelope = (float)Math.min(1.0, ticks / 10.0);
        cir.setReturnValue(cir.getReturnValue() + kick * envelope * (float)ModConfig.cameraShake);
    }
}
