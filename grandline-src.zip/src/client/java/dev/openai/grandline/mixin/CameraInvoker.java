package dev.openai.grandline.mixin;

import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Camera.class)
public interface CameraInvoker {
    @Invoker("getMaxZoom")
    float grandlinequakes$getMaxZoom(float distance);
}
