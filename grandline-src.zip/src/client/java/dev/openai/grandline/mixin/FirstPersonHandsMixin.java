package dev.openai.grandline.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.openai.grandline.item.DevilFruitItem;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.PowerState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.FirstPersonHandsAndItemsRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.client.renderer.state.level.PlayerRenderState;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Dedicated first-person staging layered around Mojang's normal hand/item submission. */
@Mixin(FirstPersonHandsAndItemsRenderer.class)
public abstract class FirstPersonHandsMixin {
    @Inject(method = "submitArmWithItem", at = @At("HEAD"))
    private void grandlinequakes$pushTechniquePose(PlayerRenderState playerState,
                                                   FirstPersonHandsAndItemsRenderState state,
                                                   float partialTicks, float xRot,
                                                   InteractionHand hand, float attack,
                                                   ItemStack itemStack, float inverseArmHeight,
                                                   PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
                                                   int lightCoords, CallbackInfo ci) {
        poseStack.pushPose();
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        float side = hand == InteractionHand.MAIN_HAND ? 1.0f : -1.0f;

        if (itemStack.getItem() instanceof DevilFruitItem && state.useItemRemainingTicks > 0) {
            float used = Math.max(0f, (hand == InteractionHand.MAIN_HAND ? state.mainHandUseDuration : state.offHandUseDuration)
                    - state.useItemRemainingTicks + partialTicks);
            float chew = (float)Math.sin(used * .72f);
            poseStack.translate(-0.16f * side, 0.10f + Math.abs(chew) * .025f, -0.18f);
            poseStack.rotateDegrees(Axis.XP, -26f + chew * 3.5f);
            poseStack.rotateDegrees(Axis.YP, -18f * side + chew * 2f);
            poseStack.rotateDegrees(Axis.ZP, 8f * side);
            return;
        }

        // Full Dragon never exposes a human arm, even between numbered abilities or while
        // sustaining the special held-M1 breath. The world-space dragon head/jaw is the actual
        // first-person body reference in this form.
        if (PowerState.form(mc.player) == DragonForm.DRAGON) {
            poseStack.translate(0f, -8f, 0f);
            return;
        }

        int action = PowerState.action(mc.player);
        int ticks = PowerState.actionTicks(mc.player);
        if (action == 0 || ticks <= 0) return;
        int family = action / 100;
        int slot = Math.floorMod(action, 100);
        float tremor = (float)Math.sin((mc.player.tickCount + partialTicks) * 1.55f);

        if (family == 1) {
            if (slot == 1 && hand == InteractionHand.MAIN_HAND) {
                poseStack.translate(-.12f, .08f, -.24f);
                poseStack.rotateDegrees(Axis.XP, -42f);
                poseStack.rotateDegrees(Axis.YP, -24f);
                poseStack.translate(tremor*.006f, tremor*.004f, 0f);
            } else if (slot == 2) {
                poseStack.translate(-.10f*side, .02f, -.20f);
                poseStack.rotateDegrees(Axis.YP, -28f*side);
                poseStack.rotateDegrees(Axis.XP, -21f);
            } else if (slot == 3 && hand == InteractionHand.MAIN_HAND) {
                poseStack.translate(0f, .19f, -.18f);
                poseStack.rotateDegrees(Axis.XP, -63f);
            } else if (slot == 4) {
                poseStack.translate(-.12f*side, -.02f, -.13f);
                poseStack.rotateDegrees(Axis.ZP, -22f*side);
            } else if (slot == 5) {
                poseStack.translate(-.18f*side, .04f, -.30f);
                poseStack.rotateDegrees(Axis.YP, -40f*side);
                poseStack.rotateDegrees(Axis.XP, -18f);
            }
        } else if (family == 2) {
            if (slot == 1 && hand == InteractionHand.MAIN_HAND) {
                poseStack.translate(-.12f, .02f, -.22f);
                poseStack.rotateDegrees(Axis.ZP, -30f);
                poseStack.rotateDegrees(Axis.XP, -28f);
            } else if (slot == 2) {
                poseStack.translate(-.10f*side, .08f, -.18f);
                poseStack.rotateDegrees(Axis.YP, -20f*side);
                poseStack.rotateDegrees(Axis.XP, -14f);
            } else if (slot == 3) {
                poseStack.translate(0f, .13f, -.26f);
                poseStack.rotateDegrees(Axis.XP, -20f);
            } else if (slot == 4) {
                poseStack.translate(-.13f*side, .04f, -.20f);
                poseStack.rotateDegrees(Axis.ZP, -26f*side);
            } else if (slot == 5) {
                poseStack.translate(-.18f*side, .02f, -.24f);
                poseStack.rotateDegrees(Axis.ZP, -46f*side + tremor*2f);
                poseStack.rotateDegrees(Axis.XP, -16f);
            }
        } else if (family == 3) {
            // Hybrid form keeps a distinct first-person rhythm even though the world rig owns the
            // third-person body. These poses stage the held item/hands around that synchronized attack.
            if (slot == 1) {
                poseStack.translate(-.20f*side, .10f, -.42f);
                poseStack.rotateDegrees(Axis.XP, -54f);
                poseStack.rotateDegrees(Axis.YP, -34f*side);
                poseStack.rotateDegrees(Axis.ZP, (-20f+tremor*1.6f)*side);
            } else if (slot == 2) {
                float cadence=(float)Math.sin((34-ticks)*1.12f);
                poseStack.translate(-.15f*side, cadence*.06f, -.28f-Math.abs(cadence)*.10f);
                poseStack.rotateDegrees(Axis.XP, -32f-cadence*22f);
                poseStack.rotateDegrees(Axis.ZP, cadence*18f*side);
            } else if (slot == 3) {
                poseStack.translate(-.23f*side, .20f, .05f);
                poseStack.rotateDegrees(Axis.XP, 28f);
                poseStack.rotateDegrees(Axis.ZP, 24f*side);
            } else if (slot == 4) {
                poseStack.translate(-.08f*side, .02f, -.48f);
                poseStack.rotateDegrees(Axis.XP, -60f);
                poseStack.rotateDegrees(Axis.YP, -14f*side);
            } else if (slot == 5) {
                poseStack.translate(-.28f*side, -.04f, -.32f);
                poseStack.rotateDegrees(Axis.ZP, -58f*side+tremor*2.4f);
                poseStack.rotateDegrees(Axis.XP, -22f);
            }
        } else if (family == 4 || family == 5) {
            // In Full Dragon the human first-person arm would break the transformation illusion. The
            // actual animated jaw/body exists in world space at the dragon-head camera, so hide it.
            poseStack.translate(0f, -8f, 0f);
        }
    }

    @Inject(method = "submitArmWithItem", at = @At("RETURN"))
    private void grandlinequakes$popTechniquePose(PlayerRenderState playerState,
                                                  FirstPersonHandsAndItemsRenderState state,
                                                  float partialTicks, float xRot,
                                                  InteractionHand hand, float attack,
                                                  ItemStack itemStack, float inverseArmHeight,
                                                  PoseStack poseStack, SubmitNodeCollector submitNodeCollector,
                                                  int lightCoords, CallbackInfo ci) {
        poseStack.popPose();
    }
}
