package dev.openai.grandline.network;

import dev.openai.grandline.GrandLineQuakes;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record ControlPayload(int flags) implements CustomPacketPayload {
    public static final Identifier ID = GrandLineQuakes.id("control");
    public static final Type<ControlPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, ControlPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ControlPayload::flags, ControlPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
