package dev.openai.grandline.network;

import dev.openai.grandline.ability.AbilityEngine;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

public final class ModNetworking {
    private ModNetworking() {}

    public static void initialize() {
        PayloadTypeRegistry.serverboundPlay().register(AbilityPayload.TYPE, AbilityPayload.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(ControlPayload.TYPE, ControlPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(AbilityPayload.TYPE, (payload, context) -> {
            if (payload.slot() >= 1 && payload.slot() <= 5) {
                AbilityEngine.tryActivate(context.player(), payload.slot());
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(ControlPayload.TYPE, (payload, context) ->
                AbilityEngine.updateControls(context.player(), payload.flags()));
    }
}
