package dev.openai.grandline.network;

import dev.openai.grandline.GrandLineQuakes;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

public record AbilityPayload(int slot) implements CustomPacketPayload {
    public static final Identifier ID = GrandLineQuakes.id("ability");
    public static final Type<AbilityPayload> TYPE = new Type<>(ID);
    public static final StreamCodec<RegistryFriendlyByteBuf, AbilityPayload> CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, AbilityPayload::slot, AbilityPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
