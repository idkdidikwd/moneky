package dev.openai.grandline.visual;

import dev.openai.grandline.ability.CinematicScheduler;
import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.world.CommandUtil;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.atomic.AtomicLong;

public final class DisplayFx {
    private static final AtomicLong IDS = new AtomicLong();

    private DisplayFx() {}

    public static String shard(ServerPlayer player, Vec3 pos, String block, double sx, double sy, double sz,
                               float yaw, float pitch, int lifetime, String familyTag) {
        String tag = safe(familyTag) + "_" + Long.toUnsignedString(IDS.incrementAndGet(), 36);
        String owner = ownerTag(player);
        String nbt = "{Tags:[\"" + tag + "\",\"glq_fx\",\"" + owner + "\"],block_state:{Name:\"" + block
                + "\"},teleport_duration:2,view_range:128f,shadow_radius:0f,shadow_strength:0f,"
                + "brightness:{block:15,sky:15},transformation:{translation:[0f,0f,0f],"
                + "left_rotation:[0f,0f,0f,1f],scale:[" + f(sx) + "f," + f(sy) + "f," + f(sz)
                + "f],right_rotation:[0f,0f,0f,1f]}}";
        CommandUtil.run(player, "summon minecraft:block_display " + p(pos) + " " + nbt);
        CommandUtil.run(player, "tp @e[type=minecraft:block_display,tag=" + tag + ",limit=1] "
                + p(pos) + " " + f(yaw) + " " + f(pitch));
        if (lifetime > 0) CinematicScheduler.schedule(player, lifetime,
                () -> CommandUtil.run(player, "kill @e[type=minecraft:block_display,tag=" + tag + "]"));
        return tag;
    }

    /** Removes transient VFX owned by one player from every dimension (login/disconnect/crash cleanup). */
    public static void clearOwner(ServerPlayer player) {
        String owner = ownerTag(player);
        for (var level : player.serverLevel().getServer().getAllLevels()) {
            String dimension = level.dimension().identifier().toString();
            CommandUtil.run(player, "execute in " + dimension
                    + " run kill @e[type=minecraft:block_display,tag=" + owner + "]");
        }
    }

    public static void move(ServerPlayer player, String tag, Vec3 pos, float yaw, float pitch) {
        CommandUtil.run(player, "tp @e[type=minecraft:block_display,tag=" + safe(tag) + ",limit=1] "
                + p(pos) + " " + f(yaw) + " " + f(pitch));
    }

    public static void kill(ServerPlayer player, String tag) {
        CommandUtil.run(player, "kill @e[type=minecraft:block_display,tag=" + safe(tag) + "]");
    }

    public static void particle(ServerPlayer player, String particle, Vec3 pos, double dx, double dy, double dz,
                                double speed, int count) {
        int scaled = count <= 0 ? count : Math.max(1, (int)Math.round(count * qualityScale()));
        CommandUtil.run(player, "particle " + particle + " " + p(pos) + " "
                + f(dx) + " " + f(dy) + " " + f(dz) + " " + f(speed) + " " + scaled + " force");
    }

    /**
     * Builds a thin world-space ring from short block-display segments. Unlike a particle circle this
     * keeps parallax and thickness when viewed from the side, so compression/shock fronts read in 3D.
     */
    public static void pressureRing(ServerPlayer player, Vec3 center, Vec3 normal, double radius,
                                    int pieces, String block, int life, String familyTag) {
        Vec3 n = normal.lengthSqr() < 1.0e-6 ? new Vec3(0, 0, 1) : normal.normalize();
        Vec3 axis = Math.abs(n.y) > .88 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 right = n.cross(axis);
        if (right.lengthSqr() < 1.0e-6) right = new Vec3(1, 0, 0);
        right = right.normalize();
        Vec3 up = right.cross(n).normalize();
        int count = Math.max(6, (int)Math.round(pieces * qualityScale()));
        double segment = Math.max(.14, 2.0 * Math.PI * radius / count * .72);
        for (int i = 0; i < count; i++) {
            double a = Math.PI * 2.0 * i / count;
            Vec3 radial = right.scale(Math.cos(a)).add(up.scale(Math.sin(a)));
            Vec3 tangent = right.scale(-Math.sin(a)).add(up.scale(Math.cos(a)));
            Vec3 pos = center.add(radial.scale(radius));
            shard(player, pos, block, .055, .055, segment,
                    yaw(tangent), pitch(tangent), life, familyTag);
        }
    }

    /** Layered ring shell used for quake hypocenters and transformation pressure pulses. */
    public static void pressureShell(ServerPlayer player, Vec3 center, Vec3 facing, double radius,
                                     String block, int life, String familyTag) {
        pressureRing(player, center, facing, radius, 12, block, life, familyTag);
        Vec3 right = facing.cross(new Vec3(0,1,0));
        if (right.lengthSqr() < 1.0e-6) right = new Vec3(1,0,0);
        pressureRing(player, center, right.normalize(), radius * .92, 10, block, life, familyTag + "_b");
        pressureRing(player, center, new Vec3(0,1,0), radius * .84, 10, block, life, familyTag + "_c");
    }

    /** World-space crescent made of short solid segments in the plane perpendicular to travel. */
    public static void crescent(ServerPlayer player, Vec3 center, Vec3 direction, double radius,
                                int pieces, String block, int life, String familyTag) {
        Vec3 f = direction.lengthSqr() < 1.0e-6 ? new Vec3(0,0,1) : direction.normalize();
        Vec3 right = f.cross(new Vec3(0,1,0));
        if (right.lengthSqr() < 1.0e-6) right = new Vec3(1,0,0);
        right = right.normalize();
        Vec3 up = right.cross(f).normalize();
        int count = Math.max(5, (int)Math.round(pieces * qualityScale()));
        for (int i=0;i<count;i++) {
            double t = i/(double)Math.max(1,count-1);
            double a = -1.22 + t*2.44;
            Vec3 radial = right.scale(Math.sin(a)).add(up.scale(Math.cos(a)));
            Vec3 tangent = right.scale(Math.cos(a)).add(up.scale(-Math.sin(a))).normalize();
            Vec3 pos = center.add(radial.scale(radius));
            double len = Math.max(.35, radius*2.20/count);
            shard(player,pos,block,.075,.12,len, yaw(tangent),pitch(tangent),life,familyTag);
        }
        particle(player,"minecraft:cloud",center,radius*.42,radius*.42,radius*.42,.018,Math.max(3,count/2));
    }

    public static void lightningArc(ServerPlayer player, Vec3 from, Vec3 to, String block, int life) {
        Vec3 delta = to.subtract(from);
        int pieces = Math.max(3, (int)Math.ceil(delta.length() * 2.2 * qualityScale()));
        Vec3 right = new Vec3(-delta.z, 0, delta.x).normalize();
        for (int i = 0; i < pieces; i++) {
            double t = i / (double)Math.max(1, pieces - 1);
            double jitter = Math.sin((i + IDS.get()) * 4.71) * 0.16;
            Vec3 p = from.add(delta.scale(t)).add(right.scale(jitter));
            shard(player, p, block, 0.07, 0.07, Math.max(0.18, delta.length()/pieces*1.25),
                    yaw(delta), pitch(delta), life, "glq_arc");
        }
    }

    public static float yaw(Vec3 v) {
        return (float)(Math.toDegrees(Math.atan2(-v.x, v.z)));
    }

    public static float pitch(Vec3 v) {
        double h = Math.sqrt(v.x*v.x + v.z*v.z);
        return (float)(-Math.toDegrees(Math.atan2(v.y, Math.max(1.0e-6, h))));
    }

    public static String p(Vec3 v) {
        return f(v.x) + " " + f(v.y) + " " + f(v.z);
    }

    private static String ownerTag(ServerPlayer player) {
        return "glq_fx_owner_" + player.getUUID().toString().replace("-", "");
    }

    private static String safe(String value) {
        return value.replaceAll("[^A-Za-z0-9_\\-]", "_");
    }

    private static double qualityScale() {
        return switch (ModConfig.vfxQuality) {
            case LOW -> 0.40;
            case MEDIUM -> 0.68;
            case HIGH -> 1.0;
            case CINEMATIC -> 1.28;
        };
    }

    private static String f(double v) { return CommandUtil.f(v); }
}
