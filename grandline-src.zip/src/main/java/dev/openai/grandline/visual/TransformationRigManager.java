package dev.openai.grandline.visual;

import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.world.CommandUtil;
import dev.openai.grandline.world.DragonController;
import dev.openai.grandline.world.WorldOps;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Server-authored multipart transformation rigs. Block displays are used instead of a client-only
 * entity renderer so the same articulated silhouette is visible to every observer without trusting
 * the client for transformation state. The hidden vanilla player remains the authoritative health/physics
 * entity; server-authored interaction proxies extend receiving hit detection across the larger silhouette.
 */
public final class TransformationRigManager {
    private static final Map<UUID, Rig> RIGS = new HashMap<>();
    /** Fixed-size heading history gives the serpentine body real turning follow-through without per-tick allocations. */
    private static final Map<UUID, HeadingHistory> DRAGON_HEADINGS = new HashMap<>();

    private TransformationRigManager() {}

    public static void tick(ServerPlayer player) {
        DragonForm form = PowerState.form(player);
        if (form == DragonForm.HUMAN) {
            remove(player);
            return;
        }
        String dimension = player.serverLevel().dimension().identifier().toString();
        Rig rig = RIGS.get(player.getUUID());
        boolean created = false;
        if (rig == null || rig.form != form || !rig.dimension.equals(dimension)) {
            remove(player);
            rig = create(player, form, dimension);
            RIGS.put(player.getUUID(), rig);
            created = true;
        }

        // Client AvatarRendererMixin suppresses the vanilla model; the server never makes the Player
        // invisible, so mob AI, targeting and all normal gameplay visibility semantics remain intact.
        if (form == DragonForm.DRAGON) {
            DRAGON_HEADINGS.computeIfAbsent(player.getUUID(), ignored -> new HeadingHistory())
                    .push(flat(WorldOps.safeLook(player)));
        } else {
            DRAGON_HEADINGS.remove(player.getUUID());
        }
        int updateEvery = switch (ModConfig.vfxQuality) {
            case CINEMATIC, HIGH -> 1;
            case MEDIUM -> 2;
            case LOW -> 3;
        };
        // teleport_duration interpolates between these server-authored keyframes at reduced quality.
        if (!created && player.tickCount % updateEvery != 0) return;
        if (form == DragonForm.HYBRID) tickHybrid(player, rig);
        else tickDragon(player, rig);
    }

    public static void remove(ServerPlayer player) {
        Rig rig = RIGS.remove(player.getUUID());
        DRAGON_HEADINGS.remove(player.getUUID());
        if (rig != null) {
            String prefix = "execute in " + rig.dimension + " run ";
            for (String tag : rig.parts.values()) {
                CommandUtil.run(player, prefix + "kill @e[type=minecraft:block_display,tag=" + tag + "]");
            }
            for (String tag : rig.hitboxes.values()) {
                CommandUtil.run(player, prefix + "kill @e[type=minecraft:interaction,tag=" + tag + "]");
            }
        }
    }

    public static void clearAll(ServerPlayer player) {
        remove(player);
        String owner = ownerTag(player);
        for (var level : player.serverLevel().getServer().getAllLevels()) {
            String dimension = level.dimension().identifier().toString();
            CommandUtil.run(player, "execute in " + dimension + " run kill @e[tag=" + owner + "]");
        }
    }

    private static Rig create(ServerPlayer player, DragonForm form, String dimension) {
        Map<String, String> parts = new LinkedHashMap<>();
        Map<String, String> hitboxes = new LinkedHashMap<>();
        String owner = ownerTag(player);
        Vec3 p = player.position();
        if (form == DragonForm.HYBRID) {
            // Coherent humanoid-dragon anatomy: head/snout/fangs/horns/mane, articulated limbs and tail.
            add(parts, "chest", part(player,p,"minecraft:prismarine",.92,1.05,.52,"hy_chest",owner));
            add(parts, "waist", part(player,p,"minecraft:dark_prismarine",.66,.48,.44,"hy_waist",owner));
            add(parts, "neck", part(player,p,"minecraft:cyan_concrete",.43,.42,.43,"hy_neck",owner));
            add(parts, "head", part(player,p,"minecraft:cyan_concrete",.70,.64,.66,"hy_head",owner));
            add(parts, "snout", part(player,p,"minecraft:prismarine",.52,.28,.48,"hy_snout",owner));
            add(parts, "eye_l", part(player,p,"minecraft:sea_lantern",.10,.10,.08,"hy_eye_l",owner));
            add(parts, "eye_r", part(player,p,"minecraft:sea_lantern",.10,.10,.08,"hy_eye_r",owner));
            add(parts, "fang_l", part(player,p,"minecraft:quartz_block",.08,.24,.08,"hy_fang_l",owner));
            add(parts, "fang_r", part(player,p,"minecraft:quartz_block",.08,.24,.08,"hy_fang_r",owner));
            add(parts, "horn_l", part(player,p,"minecraft:dark_prismarine",.15,.78,.15,"hy_horn_l",owner));
            add(parts, "horn_r", part(player,p,"minecraft:dark_prismarine",.15,.78,.15,"hy_horn_r",owner));
            add(parts, "mane_l", part(player,p,"minecraft:white_wool",.24,.52,.20,"hy_mane_l",owner));
            add(parts, "mane_r", part(player,p,"minecraft:white_wool",.24,.52,.20,"hy_mane_r",owner));
            // Authored temporary kanabo silhouette for Haki-heavy Hybrid melee techniques.
            add(parts, "kanabo_grip", part(player,p,"minecraft:blackstone",.18,.18,1.45,"hy_kanabo_grip",owner));
            add(parts, "kanabo_head", part(player,p,"minecraft:polished_blackstone",.48,.48,1.65,"hy_kanabo_head",owner));
            for (String side : new String[]{"l","r"}) {
                add(parts, "shoulder_"+side, part(player,p,"minecraft:dark_prismarine",.36,.36,.36,"hy_shoulder_"+side,owner));
                add(parts, "upper_arm_"+side, part(player,p,"minecraft:cyan_concrete",.30,.70,.30,"hy_upper_arm_"+side,owner));
                add(parts, "forearm_"+side, part(player,p,"minecraft:prismarine",.32,.66,.32,"hy_forearm_"+side,owner));
                add(parts, "claw_"+side, part(player,p,"minecraft:quartz_block",.30,.18,.52,"hy_claw_"+side,owner));
                add(parts, "thigh_"+side, part(player,p,"minecraft:cyan_concrete",.38,.78,.38,"hy_thigh_"+side,owner));
                add(parts, "shin_"+side, part(player,p,"minecraft:prismarine",.34,.72,.34,"hy_shin_"+side,owner));
                add(parts, "foot_"+side, part(player,p,"minecraft:dark_prismarine",.38,.20,.58,"hy_foot_"+side,owner));
            }
            for (int i=0;i<8;i++) {
                double taper = Math.max(.12, .34-i*.027);
                add(parts,"tail_"+i,part(player,p,i%2==0?"minecraft:cyan_concrete":"minecraft:prismarine",
                        taper,taper*.86,.66,"hy_tail_"+i,owner));
            }
            // Interaction entities extend receiving hit detection to the transformed silhouette while
            // keeping the vanilla player as the authoritative health/physics entity.
            add(hitboxes,"core",hitbox(player,p,1.22,2.95,"hy_hit_core",owner));
            add(hitboxes,"tail",hitbox(player,p,.90,1.10,"hy_hit_tail",owner));
        } else {
            // Giant serpentine body with a jaw that can open, facial detail, mane and articulated limbs.
            add(parts,"head",part(player,p,"minecraft:cyan_concrete",1.85,1.28,2.15,"dr_head",owner));
            add(parts,"muzzle",part(player,p,"minecraft:prismarine",1.42,.58,1.38,"dr_muzzle",owner));
            add(parts,"jaw",part(player,p,"minecraft:dark_prismarine",1.34,.34,1.45,"dr_jaw",owner));
            add(parts,"eye_l",part(player,p,"minecraft:sea_lantern",.24,.24,.18,"dr_eye_l",owner));
            add(parts,"eye_r",part(player,p,"minecraft:sea_lantern",.24,.24,.18,"dr_eye_r",owner));
            add(parts,"fang_l",part(player,p,"minecraft:quartz_block",.15,.58,.15,"dr_fang_l",owner));
            add(parts,"fang_r",part(player,p,"minecraft:quartz_block",.15,.58,.15,"dr_fang_r",owner));
            add(parts,"horn_l",part(player,p,"minecraft:dark_prismarine",.28,1.55,.28,"dr_horn_l",owner));
            add(parts,"horn_r",part(player,p,"minecraft:dark_prismarine",.28,1.55,.28,"dr_horn_r",owner));
            for (int i=0;i<22;i++) {
                double s=Math.max(.48,1.48-i*.045);
                add(parts,"body_"+i,part(player,p,i%3==0?"minecraft:prismarine":"minecraft:cyan_concrete",
                        s,s*.72,1.52,"dr_body_"+i,owner));
            }
            for (int i=0;i<12;i++) add(parts,"mane_"+i,part(player,p,"minecraft:white_wool",.40,.46,.86,"dr_mane_"+i,owner));
            for (int i=0;i<4;i++) {
                add(parts,"leg_"+i,part(player,p,"minecraft:cyan_concrete",.42,.42,1.38,"dr_leg_"+i,owner));
                add(parts,"claw_"+i,part(player,p,"minecraft:quartz_block",.46,.24,.82,"dr_claw_"+i,owner));
            }
            add(hitboxes,"head",hitbox(player,p,2.8,2.3,"dr_hit_head",owner));
            for (int i : new int[]{0,4,8,12,16,20}) {
                double width=Math.max(1.25,2.85-i*.065);
                add(hitboxes,"body_"+i,hitbox(player,p,width,Math.max(1.15,width*.72),"dr_hit_body_"+i,owner));
            }
        }
        return new Rig(form, parts, hitboxes, dimension, owner, player.tickCount, new Vec3[22]);
    }

    private static void add(Map<String,String> parts, String name, String tag) { parts.put(name, tag); }

    private static String part(ServerPlayer p, Vec3 pos, String block, double sx,double sy,double sz,String name,String owner) {
        String tag = owner + "_" + name;
        String nbt = "{Tags:[\"" + tag + "\",\"" + owner + "\",\"glq_rig\"],block_state:{Name:\"" + block
                + "\"},teleport_duration:2,view_range:256f,shadow_radius:0f,brightness:{block:12,sky:15},"
                + "transformation:{scale:[" + f(sx)+"f,"+f(sy)+"f,"+f(sz)+"f]}}";
        CommandUtil.run(p,"summon minecraft:block_display "+DisplayFx.p(pos)+" "+nbt);
        return tag;
    }


    private static String hitbox(ServerPlayer p, Vec3 pos, double width, double height, String name, String owner) {
        String tag = owner + "_" + name;
        String nbt = "{Tags:[\"" + tag + "\",\"" + owner + "\",\"glq_transform_hitbox\"],"
                + "width:" + f(width) + "f,height:" + f(height) + "f,response:1b}";
        CommandUtil.run(p,"summon minecraft:interaction " + DisplayFx.p(pos) + " " + nbt);
        return tag;
    }

    private static void tickHybrid(ServerPlayer player, Rig rig) {
        long frame = player.tickCount;
        Vec3 look = flat(WorldOps.safeLook(player));
        Vec3 right = WorldOps.right(look);
        // The transformed anatomy rises into place instead of popping from Steve to a finished rig.
        double emerge = clamp01((frame - rig.createdTick) / 14.0);
        double ease = 1.0 - Math.pow(1.0-emerge, 3.0);
        Vec3 base = player.position().add(0,-1.65*(1.0-ease),0);
        float yaw = DisplayFx.yaw(look);
        double speed = player.getDeltaMovement().horizontalDistance();
        double gait = Math.sin(frame * (.18 + Math.min(.20, speed*.16))) * Math.min(1.0, speed*2.5);
        int action = PowerState.action(player);
        boolean striking = action / 100 == 3 && action % 100 <= 4;
        double strike = striking ? Math.sin(Math.min(Math.PI, (34-PowerState.actionTicks(player))*.20)) : 0.0;
        double bob = Math.abs(gait) * .08;

        move(player,rig,"chest",base.add(0,1.48+bob,0),yaw, striking ? -8f : 0f);
        move(player,rig,"waist",base.add(0,.78+bob*.45,0),yaw,0);
        move(player,rig,"neck",base.add(0,2.00+bob,0),yaw,0);
        Vec3 head=base.add(0,2.40+bob,0).add(look.scale(.04));
        move(player,rig,"head",head,yaw,0);
        move(player,rig,"snout",head.add(look.scale(.48)).add(0,-.08,0),yaw,0);
        move(player,rig,"eye_l",head.add(right.scale(.25)).add(look.scale(.35)).add(0,.10,0),yaw,0);
        move(player,rig,"eye_r",head.add(right.scale(-.25)).add(look.scale(.35)).add(0,.10,0),yaw,0);
        move(player,rig,"fang_l",head.add(right.scale(.22)).add(look.scale(.58)).add(0,-.31,0),yaw,0);
        move(player,rig,"fang_r",head.add(right.scale(-.22)).add(look.scale(.58)).add(0,-.31,0),yaw,0);
        move(player,rig,"horn_l",head.add(right.scale(.28)).add(look.scale(-.18)).add(0,.55,0),yaw,-28);
        move(player,rig,"horn_r",head.add(right.scale(-.28)).add(look.scale(-.18)).add(0,.55,0),yaw,-28);
        move(player,rig,"mane_l",head.add(right.scale(.32)).add(look.scale(-.34)).add(0,.08,0),yaw,10);
        move(player,rig,"mane_r",head.add(right.scale(-.32)).add(look.scale(-.34)).add(0,.08,0),yaw,10);
        moveHitbox(player,rig,"core",base.add(0,-.10,0));
        moveHitbox(player,rig,"tail",base.add(look.scale(-2.25)).add(0,.45,0));

        for (int sideIndex=0;sideIndex<2;sideIndex++) {
            String side=sideIndex==0?"l":"r";
            double sign=sideIndex==0?1.0:-1.0;
            double armSwing=(sideIndex==0?-gait:gait)*26.0 + (sideIndex==0?strike:-strike*.38)*68.0;
            Vec3 shoulder=base.add(right.scale(sign*.62)).add(0,1.72+bob,0);
            Vec3 upper=shoulder.add(look.scale(strike*(sideIndex==0?.30:.05))).add(0,-.34,0);
            Vec3 fore=upper.add(look.scale(strike*(sideIndex==0?.48:.08))).add(0,-.55,0);
            Vec3 claw=fore.add(look.scale(.24 + strike*(sideIndex==0?.62:.12))).add(0,-.37,0);
            move(player,rig,"shoulder_"+side,shoulder,yaw,0);
            move(player,rig,"upper_arm_"+side,upper,yaw,(float)armSwing);
            move(player,rig,"forearm_"+side,fore,yaw,(float)(armSwing*.72));
            move(player,rig,"claw_"+side,claw,yaw,(float)(armSwing*.36));

            double legSwing=(sideIndex==0?gait:-gait)*20.0;
            Vec3 thigh=base.add(right.scale(sign*.30)).add(0,.48,0);
            Vec3 shin=base.add(right.scale(sign*.30)).add(look.scale(gait*sign*.16)).add(0,-.10,0);
            Vec3 foot=base.add(right.scale(sign*.30)).add(look.scale(.20+gait*sign*.28)).add(0,-.45,0);
            move(player,rig,"thigh_"+side,thigh,yaw,(float)legSwing);
            move(player,rig,"shin_"+side,shin,yaw,(float)(-legSwing*.72));
            move(player,rig,"foot_"+side,foot,yaw,0);
        }

        boolean kanabo = action == 301 || action == 302;
        if (kanabo) {
            double swing = action == 301 ? strike : Math.sin((34 - PowerState.actionTicks(player)) * .72) * .65;
            Vec3 hand = base.add(right.scale(.73)).add(0,1.05,0).add(look.scale(.34 + swing*.38));
            Vec3 shaft = hand.add(look.scale(.60)).add(0,.12 + swing*.28,0);
            Vec3 headPos = shaft.add(look.scale(.92)).add(0,.10 + swing*.22,0);
            move(player,rig,"kanabo_grip",shaft,yaw,(float)(-12 - swing*54));
            move(player,rig,"kanabo_head",headPos,yaw,(float)(-12 - swing*54));
        } else {
            Vec3 hidden = base.add(0,-96,0);
            move(player,rig,"kanabo_grip",hidden,yaw,0);
            move(player,rig,"kanabo_head",hidden,yaw,0);
        }

        Vec3 tailBase=base.add(look.scale(-.43)).add(0,.98,0);
        for(int t=0;t<8;t++){
            double wave=Math.sin(frame*.17-t*.66)*(.10+.035*t);
            double lift=Math.sin(frame*.09-t*.42)*.07-.055*t;
            Vec3 pos=tailBase.add(look.scale(-.49*t)).add(right.scale(wave)).add(0,lift,0);
            move(player,rig,"tail_"+t,pos,yaw+(float)(Math.cos(frame*.17-t*.66)*7.0),6);
        }
    }

    private static void tickDragon(ServerPlayer player, Rig rig) {
        long frame = player.tickCount;
        Vec3 look = WorldOps.safeLook(player);
        Vec3 flat = flat(look);
        Vec3 right = WorldOps.right(flat);
        // Full Dragon emerges head-first and then uncoils into its full length over ~1.1 seconds.
        double emerge = clamp01((frame - rig.createdTick) / 22.0);
        double ease = 1.0 - Math.pow(1.0-emerge, 3.0);
        Vec3 head = player.position().add(look.scale(1.20 + 2.20*ease)).add(0,.45 + 1.75*ease,0);
        float yaw = DisplayFx.yaw(flat);
        float pitch = DisplayFx.pitch(look);
        boolean breathing = DragonController.isBreathing(player);
        float jawPitch = breathing ? 28f + (float)Math.sin(frame*.45)*3f : (float)(Math.sin(frame*.08)*2f);

        move(player,rig,"head",head,yaw,pitch);
        move(player,rig,"muzzle",head.add(look.scale(.98)).add(0,-.20,0),yaw,pitch);
        move(player,rig,"jaw",head.add(look.scale(1.05)).add(0,-.67,0),yaw,pitch+jawPitch);
        move(player,rig,"eye_l",head.add(right.scale(.65)).add(look.scale(.68)).add(0,.18,0),yaw,pitch);
        move(player,rig,"eye_r",head.add(right.scale(-.65)).add(look.scale(.68)).add(0,.18,0),yaw,pitch);
        move(player,rig,"fang_l",head.add(right.scale(.50)).add(look.scale(1.30)).add(0,-.61,0),yaw,pitch+8);
        move(player,rig,"fang_r",head.add(right.scale(-.50)).add(look.scale(1.30)).add(0,-.61,0),yaw,pitch+8);
        move(player,rig,"horn_l",head.add(right.scale(.55)).add(look.scale(-.45)).add(0,1.08,0),yaw,-35);
        move(player,rig,"horn_r",head.add(right.scale(-.55)).add(look.scale(-.45)).add(0,1.08,0),yaw,-35);
        moveHitbox(player,rig,"head",head.add(0,-.72,0));

        Vec3 spineOrigin=head.add(flat.scale(-1.45)).add(0,-.24,0);
        HeadingHistory history=DRAGON_HEADINGS.computeIfAbsent(player.getUUID(), ignored -> new HeadingHistory());
        Vec3[] spine=rig.spineScratch;
        Vec3 cursor=spineOrigin;
        for(int s=0;s<22;s++){
            double lag=s*.53;
            double speed=Math.min(1.0,player.getDeltaMovement().length());
            double reveal=clamp01(emerge*1.65-s/32.0);
            Vec3 delayed=history.sample((int)Math.round(s*.82));
            Vec3 delayedRight=WorldOps.right(delayed);
            if(s>0) cursor=cursor.subtract(delayed.scale(1.08*reveal));
            double lateral=Math.sin(frame*(.095+speed*.035)-lag)*(.20+.030*s)*reveal;
            double rise=(Math.sin(frame*.071-lag*.63)*(.15+.018*s)-s*.030)*reveal;
            Vec3 pos=cursor.add(delayedRight.scale(lateral)).add(0,rise-(1.0-reveal)*3.0,0);
            spine[s]=pos;
            float segmentYaw=DisplayFx.yaw(delayed)+(float)(Math.cos(frame*.11-lag)*6.3);
            move(player,rig,"body_"+s,pos,segmentYaw,0);
            if (s==0 || s==4 || s==8 || s==12 || s==16 || s==20) {
                moveHitbox(player,rig,"body_"+s,pos.add(0,-.52,0));
            }
        }
        for(int m=0;m<12;m++){
            int seg=Math.min(21,m*2);
            double reveal=clamp01(emerge*1.65-seg/32.0);
            Vec3 delayed=history.sample((int)Math.round(seg*.82));
            Vec3 delayedRight=WorldOps.right(delayed);
            double flutter=Math.sin(frame*.24-m*.8)*.13*reveal;
            Vec3 pos=spine[seg].add(delayedRight.scale(flutter)).add(0,.78*reveal,0);
            move(player,rig,"mane_"+m,pos,DisplayFx.yaw(delayed)+(float)(flutter*18),-8);
        }
        for(int c=0;c<4;c++){
            int seg=3+c*5;
            double sign=c%2==0?1.0:-1.0;
            double reveal=clamp01(emerge*1.65-seg/32.0);
            Vec3 delayed=history.sample((int)Math.round(seg*.82));
            Vec3 delayedRight=WorldOps.right(delayed);
            Vec3 anchor=spine[seg].add(delayedRight.scale(sign*1.62*reveal)).add(0,-.30*reveal,0);
            double sweep=Math.sin(frame*.10-c*.9)*.18*reveal;
            move(player,rig,"leg_"+c,anchor.add(delayed.scale(sweep)),DisplayFx.yaw(delayed),(float)(22+sign*sweep*25));
            move(player,rig,"claw_"+c,anchor.add(delayed.scale(.55+sweep)).add(0,-.30,0),DisplayFx.yaw(delayed),(float)(10+sign*sweep*22));
        }

        if ((frame & 3L)==0) {
            // Flame Clouds are a visible locomotion system, not generic Creative-flight exhaust.
            Vec3 cloudRoot = player.position().add(0,-.20,0);
            for (int i=0;i<4;i++) {
                Vec3 cloud = cloudRoot.add(flat.scale(-1.5-i*3.4))
                        .add(right.scale(Math.sin(frame*.13-i)*1.1))
                        .add(0,Math.sin(frame*.09-i*.7)*.24,0);
                DisplayFx.particle(player,"minecraft:cloud",cloud,1.45,.34,1.45,.018,9);
                DisplayFx.particle(player,"minecraft:soul_fire_flame",cloud,.62,.22,.62,.012,4);
            }
            DisplayFx.particle(player,"minecraft:cloud",head.add(flat.scale(-2.0)),1.6,.50,1.6,.015,7);
            if (breathing) DisplayFx.particle(player,"minecraft:flame",dragonMouth(player),.32,.24,.32,.035,7);
        }
    }

    /**
     * Redirects melee attacks on transformation proxy hitboxes to the owning player.
     * This gives the long Dragon body and larger Hybrid silhouette meaningful receiving hit detection
     * without replacing the player entity or trusting the client for health/damage.
     */
    public static boolean redirectHit(ServerPlayer attacker, Entity hit) {
        if (!hit.getTags().contains("glq_transform_hitbox")) return false;
        for (Map.Entry<UUID,Rig> entry : RIGS.entrySet()) {
            Rig rig=entry.getValue();
            if (!hit.getTags().contains(rig.ownerTag)) continue;
            ServerPlayer owner=attacker.serverLevel().getServer().getPlayerList().getPlayer(entry.getKey());
            if (owner==null || !owner.isAlive() || owner==attacker) return true;
            // Proxy hitboxes must obey the exact same PvP/friendly-fire policy as ability damage.
            // The vanilla team rule is still honored even when the mod's friendly-fire option is enabled.
            if (!attacker.canHarmPlayer(owner) || (!ModConfig.friendlyFire && attacker.isAlliedTo(owner))) return true;

            float charge=attacker.getAttackStrengthScale(.5f);
            float base=(float)attacker.getAttributeValue(Attributes.ATTACK_DAMAGE);
            float damage=base*(.2f+charge*charge*.8f);
            if (damage>0f) {
                owner.hurtServer(owner.serverLevel(),attacker.damageSources().playerAttack(attacker),damage);
                Vec3 away=owner.position().subtract(attacker.position());
                if (away.lengthSqr()>1.0e-5) {
                    away=away.normalize();
                    owner.push(away.x*.22,.06,away.z*.22);
                }
            }
            attacker.resetAttackStrengthTicker();
            return true;
        }
        return true;
    }

    public static Vec3 dragonMouth(ServerPlayer player) {
        Vec3 look=WorldOps.safeLook(player);
        Rig rig=RIGS.get(player.getUUID());
        double ease=1.0;
        if(rig!=null && rig.form==DragonForm.DRAGON) {
            double emerge=clamp01((player.tickCount-rig.createdTick)/22.0);
            ease=1.0-Math.pow(1.0-emerge,3.0);
        }
        Vec3 head=player.position().add(look.scale(1.20+2.20*ease)).add(0,.45+1.75*ease,0);
        return head.add(look.scale(1.22)).add(0,-.38,0);
    }

    private static void moveHitbox(ServerPlayer player,Rig rig,String key,Vec3 pos){
        String tag=rig.hitboxes.get(key);
        if(tag!=null) CommandUtil.run(player,"tp @e[type=minecraft:interaction,tag="+tag+",limit=1] "+DisplayFx.p(pos));
    }

    private static void move(ServerPlayer player,Rig rig,String key,Vec3 pos,float yaw,float pitch){
        String tag=rig.parts.get(key);
        if(tag!=null) DisplayFx.move(player,tag,pos,yaw,pitch);
    }

    private static double clamp01(double value) {
        return Math.max(0.0,Math.min(1.0,value));
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f=new Vec3(v.x,0,v.z);
        return f.lengthSqr()<1.0e-4?new Vec3(0,0,1):f.normalize();
    }

    private static String ownerTag(ServerPlayer player) {
        return "glq_" + player.getUUID().toString().replace("-", "").substring(0,12);
    }

    private static String f(double d){return CommandUtil.f(d);}

    private static final class HeadingHistory {
        private static final int SIZE = 48;
        private final Vec3[] values = new Vec3[SIZE];
        private int cursor = -1;
        private int count;

        void push(Vec3 heading) {
            cursor=(cursor+1)%SIZE;
            values[cursor]=heading;
            if(count<SIZE) count++;
        }

        Vec3 sample(int ticksAgo) {
            if(count==0) return new Vec3(0,0,1);
            int delay=Math.max(0,Math.min(ticksAgo,count-1));
            int index=cursor-delay;
            if(index<0) index+=SIZE;
            Vec3 value=values[index];
            return value==null?new Vec3(0,0,1):value;
        }
    }
    private record Rig(DragonForm form, Map<String,String> parts, Map<String,String> hitboxes, String dimension, String ownerTag, long createdTick, Vec3[] spineScratch) {}
}
