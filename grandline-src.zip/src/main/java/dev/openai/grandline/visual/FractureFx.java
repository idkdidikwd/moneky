package dev.openai.grandline.visual;

import dev.openai.grandline.ability.CinematicScheduler;
import dev.openai.grandline.config.ModConfig;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * Authored spatial-fracture geometry. Branches occupy multiple depth planes and grow in timed waves;
 * thin separated "plates" sit in front of and behind the crack so the effect keeps parallax when
 * viewed from the side instead of reading as a flat sprite.
 */
public final class FractureFx {
    private FractureFx() {}

    public static void bloom(ServerPlayer player, Vec3 origin, Vec3 forward, double size, int seed, boolean sphere) {
        int branches = switch (ModConfig.vfxQuality) {
            case LOW -> 5;
            case MEDIUM -> 8;
            case HIGH -> 12;
            case CINEMATIC -> 16;
        };
        long seed64 = seed * 31L + player.getUUID().getLeastSignificantBits();
        Vec3 f = forward.lengthSqr() < 1.0e-6 ? new Vec3(0,0,1) : forward.normalize();
        Vec3 right = new Vec3(-f.z, 0, f.x);
        if (right.lengthSqr() < 0.001) right = new Vec3(1, 0, 0);
        right = right.normalize();
        Vec3 up = right.cross(f).normalize();

        DisplayFx.shard(player, origin, "minecraft:sea_lantern", 0.22, 0.22, 0.22,
                0, 0, 18, "glq_fracture_core");
        DisplayFx.pressureRing(player, origin, f, Math.max(.55, size*.16), 10,
                "minecraft:white_stained_glass", 8, "glq_fracture_initial_ring");

        for (int b = 0; b < branches; b++) {
            final int branch = b;
            // The pseudo-random stream is local to each branch so delayed execution is deterministic.
            final long branchSeed = seed64 ^ (0x9E3779B97F4A7C15L * (branch + 1L));
            CinematicScheduler.schedule(player, b % 5, () -> {
                Random rng = new Random(branchSeed);
                double angle = Math.PI * 2.0 * branch / branches + (rng.nextDouble()-.5) * 0.42;
                Vec3 radial = right.scale(Math.cos(angle)).add(up.scale(Math.sin(angle)));
                Vec3 dir = sphere
                        ? radial.add(f.scale((rng.nextDouble()-0.5) * 0.90)).normalize()
                        : radial.scale(0.72).add(f.scale(0.72 + rng.nextDouble()*0.45)).normalize();
                Vec3 cursor = origin.add(f.scale((rng.nextDouble()-.5) * size*.10));
                int segments = 3 + rng.nextInt(4);
                for (int i = 0; i < segments; i++) {
                    final int segmentIndex = i;
                    final Vec3 start = cursor;
                    final Vec3 startDir = dir;
                    final double length = size * (0.095 + rng.nextDouble()*0.075);
                    final double driftR = (rng.nextDouble()-0.5)*0.20;
                    final double driftU = (rng.nextDouble()-0.5)*0.20;
                    final boolean hasFork = i > 1 && rng.nextFloat() < 0.52f;
                    final boolean forkSide = rng.nextBoolean();
                    CinematicScheduler.schedule(player, i, () -> {
                        Vec3 localDir = startDir.add(right.scale(driftR)).add(up.scale(driftU)).normalize();
                        Vec3 end = start.add(localDir.scale(length));
                        Vec3 mid = start.add(end).scale(0.5);
                        String material = segmentIndex % 3 == 0 ? "minecraft:white_stained_glass" : "minecraft:sea_lantern";
                        DisplayFx.shard(player, mid, material,
                                0.045 + (segmentIndex%2)*.018, 0.065 + (branch%3)*.008, length,
                                DisplayFx.yaw(localDir), DisplayFx.pitch(localDir), 19 + segmentIndex*2, "glq_fracture");

                        // Offset plates create a visible broken "surface" on several depth planes.
                        if (segmentIndex > 0 && (segmentIndex + branch) % 2 == 0) {
                            double sep = .08 + .035*segmentIndex;
                            Vec3 plateCenter = mid.add(f.scale(((branch & 1)==0 ? 1 : -1) * sep));
                            DisplayFx.shard(player, plateCenter, "minecraft:white_stained_glass",
                                    Math.min(.48, length*.65), Math.min(.34, length*.42), .035,
                                    DisplayFx.yaw(f), DisplayFx.pitch(f), 13 + segmentIndex,
                                    "glq_fracture_plate");
                        }
                        if (hasFork) {
                            Vec3 side = localDir.add(radial.scale(forkSide ? .62 : -.62)).normalize();
                            Vec3 subEnd = start.add(side.scale(length * 0.70));
                            DisplayFx.shard(player, start.add(subEnd).scale(0.5), "minecraft:white_stained_glass",
                                    0.035, 0.052, length*0.70, DisplayFx.yaw(side), DisplayFx.pitch(side),
                                    15 + segmentIndex, "glq_fracture_sub");
                        }
                    });
                    dir = dir.add(right.scale(driftR)).add(up.scale(driftU)).normalize();
                    cursor = cursor.add(dir.scale(length));
                }
            });
        }

        // A second shock front arrives after the crack has had time to become readable.
        CinematicScheduler.schedule(player, 6, () -> {
            DisplayFx.pressureRing(player, origin.add(f.scale(size*.08)), f, Math.max(1.0,size*.38), 14,
                    "minecraft:white_stained_glass", 8, "glq_fracture_pressure");
            DisplayFx.particle(player, "minecraft:end_rod", origin, size*.16, size*.16, size*.16, .012, branches*3);
            DisplayFx.particle(player, "minecraft:cloud", origin.add(f.scale(size*.14)), size*.22, size*.13, size*.22,
                    .035, branches*2);
        });
    }

    public static void plane(ServerPlayer player, Vec3 origin, Vec3 forward, double size, int seed) {
        bloom(player, origin, forward, size, seed, false);
    }

    public static void shell(ServerPlayer player, Vec3 origin, double size, int seed) {
        bloom(player, origin, new Vec3(0, 1, 0), size, seed, true);
    }
}
