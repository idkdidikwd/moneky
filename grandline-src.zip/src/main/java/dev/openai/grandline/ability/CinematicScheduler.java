package dev.openai.grandline.ability;

import dev.openai.grandline.GrandLineQuakes;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/**
 * Small deterministic server-tick scheduler for authored ability beats.
 *
 * Gameplay stages can be scoped to a player UUID. Those stages are cancelled when that player
 * disconnects, changes dimension, or is replaced by a respawn entity, preventing an old
 * transformation/ultimate (including its transient-display cleanup tasks) from finishing against a
 * stale ServerPlayer. Unscoped jobs remain available for server-global work.
 */
public final class CinematicScheduler {
    private static final List<Step> STEPS = new ArrayList<>();
    private static long clock;

    private CinematicScheduler() {}

    public static void schedule(int delayTicks, Runnable action) {
        STEPS.add(new Step(clock + Math.max(0, delayTicks), null, action));
    }

    public static void schedule(ServerPlayer owner, int delayTicks, Runnable action) {
        STEPS.add(new Step(clock + Math.max(0, delayTicks), owner.getUUID(), action));
    }

    /** Cancels only gameplay/cinematic stages belonging to this player. */
    public static void cancel(UUID owner) {
        STEPS.removeIf(step -> owner.equals(step.owner()));
    }

    public static void tick() {
        clock++;
        if (STEPS.isEmpty()) return;
        STEPS.sort(Comparator.comparingLong(Step::at));
        for (int i = 0; i < STEPS.size();) {
            Step step = STEPS.get(i);
            if (step.at() > clock) break;
            STEPS.remove(i);
            try {
                step.action().run();
            } catch (RuntimeException ex) {
                // A failed cinematic stage should not take down the server, but it must never be
                // silently swallowed: the log is part of the release/QA feedback loop.
                GrandLineQuakes.LOGGER.error("Cinematic step failed at tick {}", clock, ex);
            }
        }
    }

    public static void clear() {
        STEPS.clear();
        clock = 0L;
    }

    public static long clock() { return clock; }
    static int pendingSteps() { return STEPS.size(); }
    private record Step(long at, UUID owner, Runnable action) { }
}
