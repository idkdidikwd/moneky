package dev.openai.grandline.ability;

import dev.openai.grandline.registry.ModSounds;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.visual.DisplayFx;
import dev.openai.grandline.visual.TransformationRigManager;
import dev.openai.grandline.world.DestructionManager;
import dev.openai.grandline.world.WorldOps;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

public final class SeiryuAbilities {
    private SeiryuAbilities() {}

    public static void activate(ServerPlayer p, DragonForm form, int slot) {
        switch(form){
            case HUMAN -> base(p,slot);
            case HYBRID -> hybrid(p,slot);
            case DRAGON -> dragon(p,slot);
        }
    }

    /** Crouch + ability 5 reverses one transformation tier without stealing a sixth keybind. */
    public static void revertForm(ServerPlayer p, DragonForm current) {
        if (current == DragonForm.HUMAN) return;
        PowerState.setAction(p,505,18);
        ServerLevel level=p.serverLevel();
        Vec3 center=p.position().add(0,current==DragonForm.DRAGON?2.0:1.0,0);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.TRANSFORM,SoundSource.PLAYERS,1.8f,1.18f);
        DisplayFx.pressureShell(p,center,new Vec3(0,1,0),current==DragonForm.DRAGON?4.2:2.1,
                "minecraft:cyan_stained_glass",9,"glq_revert_shell");
        DisplayFx.particle(p,"minecraft:cloud",center,current==DragonForm.DRAGON?4.0:1.8,1.0,current==DragonForm.DRAGON?4.0:1.8,.06,30);
        CinematicScheduler.schedule(p, 12,()->{
            DragonForm target=current==DragonForm.DRAGON?DragonForm.HYBRID:DragonForm.HUMAN;
            TransformationRigManager.remove(p);
            PowerState.setForm(p,target);
            PowerState.setAction(p,0,0);
            if(target!=DragonForm.HUMAN) TransformationRigManager.tick(p);
            DisplayFx.particle(p,"minecraft:flash",p.position().add(0,1.0,0),0,0,0,0,1);
        });
    }

    public static void passiveClaw(ServerPlayer p) {
        if(!p.getMainHandItem().isEmpty()) return;
        Vec3 look=WorldOps.safeLook(p);
        Vec3 origin=p.getEyePosition().add(look.scale(.7));
        Vec3 right=WorldOps.right(look);
        for(int i=-1;i<=1;i++){
            Vec3 from=origin.add(right.scale(i*.16)).add(0,.12*i,0);
            Vec3 to=from.add(look.scale(1.55)).add(right.scale(i*.18));
            DisplayFx.lightningArc(p,from,to,"minecraft:cyan_stained_glass",5);
        }
        WorldOps.damageCone(p,p.getEyePosition(),look,3.1,1.25,2.0f,.25);
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_WIND,SoundSource.PLAYERS,.75f,1.42f);
    }

    /**
     * Bare-handed Seiryu strikes against terrain keep the same directional claw language as entity
     * hits, but the impact debris is sampled from the actual struck block state. That makes stone,
     * wood, sand, leaves, etc. read as different physical impacts without spawning persistent debris.
     */
    public static void passiveClawBlock(ServerPlayer p, BlockPos pos, Direction face) {
        if(!p.getMainHandItem().isEmpty()) return;
        ServerLevel level=p.serverLevel();
        var state=level.getBlockState(pos);
        if(state.isAir()) return;

        Vec3 normal=new Vec3(face.getStepX(),face.getStepY(),face.getStepZ());
        Vec3 impact=Vec3.atCenterOf(pos).add(normal.scale(.52));
        Vec3 look=WorldOps.safeLook(p);
        Vec3 right=WorldOps.right(look);
        for(int i=-1;i<=1;i++){
            Vec3 a=p.getEyePosition().add(look.scale(.34)).add(right.scale(i*.12));
            Vec3 b=impact.add(right.scale(i*.14)).add(normal.scale(.08));
            DisplayFx.lightningArc(p,a,b,"minecraft:cyan_stained_glass",4);
        }
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK,state),
                impact.x,impact.y,impact.z,18,.28,.28,.28,.075);
        DisplayFx.particle(p,"minecraft:enchanted_hit",impact,.18,.18,.18,.015,5);
        level.playSound(null,impact.x,impact.y,impact.z,ModSounds.DRAGON_WIND,SoundSource.PLAYERS,.58f,1.55f);
    }

    private static void base(ServerPlayer p,int slot){
        switch(slot){
            case 1 -> azureClaw(p);
            case 2 -> scaleBastion(p);
            case 3 -> cloudStep(p);
            case 4 -> dragonPulse(p);
            case 5 -> transformHybrid(p);
        }
    }

    private static void hybrid(ServerPlayer p,int slot){
        switch(slot){
            case 1 -> thunderBagua(p);
            case 2 -> kundali(p);
            case 3 -> hybridBreath(p);
            case 4 -> vajra(p);
            case 5 -> transformDragon(p);
        }
    }

    private static void dragon(ServerPlayer p,int slot){
        switch(slot){
            case 1 -> dragonRush(p);
            case 2 -> kaifu(p);
            case 3 -> tatsumaki(p);
            case 4 -> tatsumakiKaifu(p);
            case 5 -> flameDragon(p);
        }
    }

    private static void azureClaw(ServerPlayer p){
        PowerState.setAction(p,201,14);
        Vec3 look=WorldOps.safeLook(p), right=WorldOps.right(look);
        WorldOps.move(p,look.scale(.58),true);
        for(int i=-1;i<=1;i++){
            Vec3 a=p.getEyePosition().add(right.scale(i*.34)).add(0,-.25,0);
            Vec3 b=a.add(look.scale(4.2)).add(right.scale(i*.22));
            DisplayFx.lightningArc(p,a,b,"minecraft:cyan_stained_glass",8);
        }
        CinematicScheduler.schedule(p, 4,()-> WorldOps.damageCone(p,p.getEyePosition(),WorldOps.safeLook(p),5.2,2.0,8.5f,1.0));
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_WIND,SoundSource.PLAYERS,1.25f,1.22f);
    }

    private static void scaleBastion(ServerPlayer p){
        PowerState.setAction(p,202,28);
        p.setAbsorptionAmount(Math.max(p.getAbsorptionAmount(),8.0f));
        Vec3 c=p.position().add(0,1,0);
        for(int i=0;i<10;i++){
            double a=Math.PI*2*i/10.0;
            DisplayFx.shard(p,c.add(Math.cos(a)*1.05,(i%3)*.38-.3,Math.sin(a)*1.05),
                    i%2==0?"minecraft:prismarine":"minecraft:dark_prismarine",
                    .16,.34,.55,(float)Math.toDegrees(a),0,40,"glq_scale");
        }
        DisplayFx.particle(p,"minecraft:enchanted_hit",c,.9,1.0,.9,.02,35);
    }

    private static void cloudStep(ServerPlayer p){
        PowerState.setAction(p,203,18);
        Vec3 look=WorldOps.safeLook(p);
        WorldOps.move(p,look.scale(1.18).add(0,.46,0),false);
        for(int i=0;i<5;i++){
            final int n=i;
            CinematicScheduler.schedule(p, n*2,()->{
                Vec3 tail=p.position().subtract(WorldOps.safeLook(p).scale(1.2+n*.45)).add(0,.35,0);
                DisplayFx.particle(p,"minecraft:cloud",tail,1.0,.35,1.0,.03,14);
                DisplayFx.particle(p,"minecraft:flame",tail,.45,.18,.45,.02,6);
            });
        }
    }

    private static void dragonPulse(ServerPlayer p){
        PowerState.setAction(p,204,24);
        ServerLevel level=p.serverLevel();
        Vec3 eye=p.getEyePosition(), look=WorldOps.safeLook(p);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_ROAR,SoundSource.PLAYERS,2.0f,.92f);
        for(int r=1;r<=4;r++){
            final int ring=r;
            CinematicScheduler.schedule(p, r*2,()->{
                Vec3 c=eye.add(look.scale(2.0+ring*2.2));
                WorldOps.damageSphere(p,c,1.7+ring*.48,2.8f+ring*.75, .35+ring*.18);
                DisplayFx.particle(p,"minecraft:sonic_boom",c,.2,.2,.2,0,1);
                DisplayFx.particle(p,"minecraft:cloud",c,ring*.8,ring*.5,ring*.8,.07,16);
            });
        }
    }

    private static void transformHybrid(ServerPlayer p){
        PowerState.setAction(p,205,50);
        ServerLevel level=p.serverLevel();
        Vec3 c=p.position().add(0,1,0);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.TRANSFORM,SoundSource.PLAYERS,2.4f,.88f);
        for(int t=0;t<=30;t+=5){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()->{
                Vec3 now=p.position().add(0,1,0);
                DisplayFx.particle(p,"minecraft:cloud",now,1.0+ft*.04,.55,1.0+ft*.04,.06,18);
                DisplayFx.particle(p,"minecraft:electric_spark",now,.75,1.0,.75,.04,14);
                if(ft%10==0) DisplayFx.lightningArc(p,now.add(-1.4,2.1,0),now.add(.9,-.3,.5),
                        "minecraft:red_stained_glass",7);
                // The silhouette physically changes before the final swap: scales, horns, claws and tail
                // flicker into existence in authored stages rather than appearing in one frame.
                if(ft>=10){
                    Vec3 facing=WorldOps.safeLook(p), side=WorldOps.right(facing);
                    Vec3 head=now.add(0,1.35,0);
                    DisplayFx.shard(p,head.add(side.scale(.28)).add(facing.scale(-.12)).add(0,.35,0),
                            "minecraft:dark_prismarine",.11,.55,.11,DisplayFx.yaw(facing),-30,7,"glq_hybrid_growth");
                    DisplayFx.shard(p,head.add(side.scale(-.28)).add(facing.scale(-.12)).add(0,.35,0),
                            "minecraft:dark_prismarine",.11,.55,.11,DisplayFx.yaw(facing),-30,7,"glq_hybrid_growth");
                    DisplayFx.shard(p,now.add(side.scale(.58)).add(facing.scale(.18)),
                            "minecraft:quartz_block",.18,.13,.42,DisplayFx.yaw(facing),0,7,"glq_hybrid_claw");
                    DisplayFx.shard(p,now.add(side.scale(-.58)).add(facing.scale(.18)),
                            "minecraft:quartz_block",.18,.13,.42,DisplayFx.yaw(facing),0,7,"glq_hybrid_claw");
                }
                if(ft>=20){
                    for(int plate=0;plate<5;plate++){
                        double a=Math.PI*2*plate/5.0+ft*.05;
                        DisplayFx.shard(p,now.add(Math.cos(a)*.52,.25+(plate%2)*.42,Math.sin(a)*.52),
                                plate%2==0?"minecraft:prismarine":"minecraft:cyan_concrete",.16,.22,.06,
                                (float)Math.toDegrees(a),0,7,"glq_hybrid_scales");
                    }
                }
            });
        }
        CinematicScheduler.schedule(p, 34,()->{
            PowerState.setForm(p,DragonForm.HYBRID);
            PowerState.setAction(p,0,0);
            TransformationRigManager.tick(p);
            WorldOps.radialImpulse(p,p.position().add(0,1,0),6,1.25);
            DisplayFx.particle(p,"minecraft:flash",p.position().add(0,1,0),0,0,0,0,1);
            level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_ROAR,SoundSource.PLAYERS,2.5f,.74f);
        });
    }

    private static void thunderBagua(ServerPlayer p){
        PowerState.setAction(p,301,18);
        Vec3 look=WorldOps.safeLook(p);
        Vec3 start=p.position().add(0,1,0);
        for(int i=0;i<4;i++){
            Vec3 a=start.add(look.scale(i*.8)).add((i&1)==0?.35:-.35,.4,0);
            Vec3 b=a.add(look.scale(2.1)).add(0,-.4,0);
            DisplayFx.lightningArc(p,a,b,"minecraft:red_stained_glass",9);
        }
        WorldOps.move(p,look.scale(1.9),false);
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.HAKI_CRACK,SoundSource.PLAYERS,2.0f,.72f);
        CinematicScheduler.schedule(p, 5,()->{
            Vec3 impact=p.getEyePosition().add(WorldOps.safeLook(p).scale(2.2));
            WorldOps.damageSphere(p,impact,3.5,20f,2.6);
            DisplayFx.particle(p,"minecraft:flash",impact,0,0,0,0,1);
            DisplayFx.particle(p,"minecraft:poof",impact,1.6,.55,1.6,.22,30);
            DestructionManager.queueDisc(p,p.serverLevel(),WorldOps.block(impact),3,1);
        });
    }

    private static void kundali(ServerPlayer p){
        PowerState.setAction(p,302,34);
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.HAKI_CRACK,SoundSource.PLAYERS,1.55f,1.05f);
        for(int hit=0;hit<6;hit++){
            final int h=hit;
            CinematicScheduler.schedule(p, 3+h*4,()->{
                Vec3 l=WorldOps.safeLook(p);
                Vec3 c=p.getEyePosition().add(l.scale(2.2+(h%2)*.5));
                WorldOps.damageSphere(p,c,2.2,h==5?9.0f:3.2f,h==5?1.8:.38);
                Vec3 r=WorldOps.right(l);
                Vec3 from=p.getEyePosition().add(r.scale((h&1)==0?.6:-.6)).add(0,-.35,0);
                DisplayFx.lightningArc(p,from,c.add(l.scale(.5)),"minecraft:red_stained_glass",6);
                DisplayFx.particle(p,h==5?"minecraft:flash":"minecraft:crit",c,.7,.5,.7,.08,h==5?1:12);
            });
        }
    }

    private static void hybridBreath(ServerPlayer p){
        PowerState.setAction(p,303,28);
        Vec3 look=WorldOps.safeLook(p);
        Vec3 mouth=p.getEyePosition().add(0,.16,0).add(look.scale(.45));
        for(int t=0;t<6;t+=2){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()-> DisplayFx.particle(p,"minecraft:flame",mouth,.15+ft*.04,.15,.15+ft*.04,.015,8));
        }
        CinematicScheduler.schedule(p, 7,()->{
            Vec3 l=WorldOps.safeLook(p), m=p.getEyePosition().add(l.scale(.55));
            WorldOps.igniteCone(p,m,l,18,3.1,10f,4);
            for(int d=2;d<=18;d+=3){
                Vec3 c=m.add(l.scale(d));
                DisplayFx.particle(p,"minecraft:flame",c,.35+d*.08,.32,.35+d*.08,.03,18);
                DisplayFx.particle(p,"minecraft:smoke",c,.25+d*.05,.2,.25+d*.05,.02,5);
            }
            p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_FLAME,SoundSource.PLAYERS,1.8f,.95f);
        });
    }

    private static void vajra(ServerPlayer p){
        PowerState.setAction(p,304,25);
        Vec3 l=WorldOps.safeLook(p), start=p.getEyePosition().add(l.scale(1.0));
        for(int s=0;s<8;s++){
            final int step=s;
            CinematicScheduler.schedule(p, step*2,()->{
                Vec3 dir=WorldOps.safeLook(p);
                Vec3 c=start.add(dir.scale(3.2*step));
                DisplayFx.lightningArc(p,c.add(-.4,.4,0),c.add(dir.scale(2.4)).add(.4,-.4,0),
                        "minecraft:red_stained_glass",7);
                DisplayFx.particle(p,"minecraft:sonic_boom",c,.1,.1,.1,0,1);
                WorldOps.damageSphere(p,c,2.5,5f,1.0);
            });
        }
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.HAKI_CRACK,SoundSource.PLAYERS,1.9f,.86f);
    }

    private static void transformDragon(ServerPlayer p){
        PowerState.setAction(p,305,78);
        ServerLevel level=p.serverLevel();
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.TRANSFORM,SoundSource.PLAYERS,3.0f,.62f);
        for(int t=0;t<48;t+=6){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()->{
                Vec3 c=p.position().add(0,2.2+ft*.018,0);
                double rad=2.2+ft*.065;
                DisplayFx.particle(p,"minecraft:cloud",c,rad,.65,rad,.04,24);
                DisplayFx.pressureRing(p,c,new Vec3(0,1,0),Math.max(1.4,rad*.70),12,
                        "minecraft:cyan_stained_glass",8,"glq_dragon_transform_ring");
                if(ft%12==0) {
                    DisplayFx.lightningArc(p,c.add(-rad,4,0),c.add(rad*.25,-1,.6),
                            "minecraft:cyan_stained_glass",10);
                    DisplayFx.lightningArc(p,c.add(rad,4,-.7),c.add(-rad*.25,-.5,0),
                            "minecraft:red_stained_glass",10);
                }
                if(ft>=24){
                    Vec3 f=WorldOps.safeLook(p);
                    Vec3 horizontal=new Vec3(f.x,0,f.z);
                    if(horizontal.lengthSqr()<.001) horizontal=new Vec3(0,0,1);
                    horizontal=horizontal.normalize();
                    Vec3 side=WorldOps.right(horizontal);
                    // Temporary emerging serpentine spine previews the body growing upward/outward.
                    Vec3 emergence=p.position().add(0,2.4+(ft-24)*.07,0).add(horizontal.scale(2.0));
                    for(int seg=0;seg<7;seg++){
                        double wave=Math.sin(ft*.15-seg*.68)*(.30+seg*.06);
                        Vec3 part=emergence.subtract(horizontal.scale(seg*1.05)).add(side.scale(wave)).add(0,seg*.12,0);
                        DisplayFx.shard(p,part,seg%2==0?"minecraft:cyan_concrete":"minecraft:prismarine",
                                .50-seg*.035,.36-seg*.022,.82,DisplayFx.yaw(horizontal),0,8,"glq_dragon_emerge");
                    }
                }
            });
        }
        CinematicScheduler.schedule(p, 52,()->{
            PowerState.setForm(p,DragonForm.DRAGON);
            PowerState.setAction(p,0,0);
            TransformationRigManager.tick(p);
            WorldOps.radialImpulse(p,p.position().add(0,2,0),11,2.0);
            DisplayFx.particle(p,"minecraft:flash",p.position().add(0,2,0),0,0,0,0,1);
            level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_ROAR,SoundSource.PLAYERS,4.0f,.58f);
        });
    }

    private static void dragonRush(ServerPlayer p){
        PowerState.setAction(p,401,26);
        Vec3 look=WorldOps.safeLook(p);
        WorldOps.move(p,look.scale(2.1),false);
        for(int t=0;t<18;t+=3){
            CinematicScheduler.schedule(p, t,()->{
                Vec3 flat=WorldOps.safeLook(p);
                flat=new Vec3(flat.x,0,flat.z);
                if(flat.lengthSqr()<.001) flat=new Vec3(0,0,1);
                flat=flat.normalize();
                Vec3 c=p.position().add(0,1.5,0);
                // The whole serpentine body is the weapon: sample the visible body line rather than
                // damaging only the hidden player's central hitbox.
                for(int segment=0;segment<6;segment++) {
                    Vec3 body=c.subtract(flat.scale(segment*3.7));
                    WorldOps.damageSphere(p,body,3.4,segment==0?7.5f:4.2f,1.1);
                    if((segment&1)==0) DisplayFx.particle(p,"minecraft:cloud",body,1.7,.75,1.7,.08,11);
                }
                DisplayFx.particle(p,"minecraft:cloud",c,2.8,1.1,2.8,.1,24);
                DestructionManager.queueDisc(p,p.serverLevel(),WorldOps.block(c),2,0);
            });
        }
    }

    private static void kaifu(ServerPlayer p){
        PowerState.setAction(p,402,34);
        Vec3 facing=WorldOps.safeLook(p);
        Vec3 right=WorldOps.right(facing);
        p.serverLevel().playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_WIND,SoundSource.PLAYERS,2.8f,.74f);
        // Three independent Demolition Gust crescents fan across the battlefield.
        for(int blade=-1;blade<=1;blade++){
            final int b=blade;
            CinematicScheduler.schedule(p, (b+1)*3,()->{
                Vec3 origin=TransformationRigManager.dragonMouth(p).add(right.scale(b*1.65));
                Vec3 dir=WorldOps.safeLook(p).add(right.scale(b*.055)).normalize();
                for(int seg=1;seg<=8;seg++){
                    final int step=seg;
                    CinematicScheduler.schedule(p, step,()->{
                        Vec3 c=origin.add(dir.scale(step*4.5));
                        DisplayFx.crescent(p,c,dir,2.2+step*.10,9,"minecraft:white_stained_glass",8,"glq_kaifu_crescent");
                        DisplayFx.particle(p,"minecraft:cloud",c,1.4,1.4,1.4,.045,9);
                        WorldOps.damageSphere(p,c,2.8,4.6f,1.0);
                    });
                }
                DestructionManager.queueLine(p,p.serverLevel(),WorldOps.block(origin),WorldOps.block(origin.add(dir.scale(36))),1);
            });
        }
    }

    private static void tatsumaki(ServerPlayer p){
        PowerState.setAction(p,403,75);
        Vec3 l=WorldOps.safeLook(p);
        Vec3 base=p.position().add(l.scale(10));
        for(int tick=0;tick<48;tick+=3){
            final int ft=tick;
            CinematicScheduler.schedule(p, tick,()->{
                double y=(ft%24)*.32;
                for(int k=0;k<10;k++){
                    double a=ft*.23+k*(Math.PI*2/10.0);
                    double r=1.2+(ft%18)*.13;
                    Vec3 c=base.add(Math.cos(a)*r,y*.55,Math.sin(a)*r);
                    DisplayFx.particle(p,"minecraft:cloud",c,.35,.2,.35,.05,5);
                }
                WorldOps.damageSphere(p,base.add(0,2.5,0),6.5,1.4f,.35);
                WorldOps.vortexImpulse(p,base.add(0,2.5,0),7.5,.72,.34);
            });
        }
        p.serverLevel().playSound(null,base.x,base.y,base.z,ModSounds.DRAGON_WIND,SoundSource.PLAYERS,3.2f,.62f);
    }

    private static void tatsumakiKaifu(ServerPlayer p){
        PowerState.setAction(p,404,105);
        Vec3 center=p.position().add(WorldOps.safeLook(p).scale(13));
        for(int t=0;t<66;t+=4){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()->{
                double r=4.5+Math.sin(ft*.17)*1.4;
                for(int k=0;k<8;k++){
                    double a=ft*.21+k*Math.PI/4;
                    Vec3 c=center.add(Math.cos(a)*r,1.0+(ft%24)*.22,Math.sin(a)*r);
                    DisplayFx.shard(p,c,"minecraft:white_stained_glass",1.8,.09,.58,
                            (float)Math.toDegrees(a),0,9,"glq_stormblade");
                    DisplayFx.particle(p,"minecraft:cloud",c,.45,.2,.45,.06,5);
                    WorldOps.damageSphere(p,c,2.0,2.8f,.55);
                }
                WorldOps.vortexImpulse(p,center.add(0,3.0,0),9.5,.78,.38);
            });
        }
        CinematicScheduler.schedule(p, 70,()->{
            WorldOps.damageSphere(p,center.add(0,3,0),11,14f,2.2);
            DisplayFx.particle(p,"minecraft:flash",center.add(0,3,0),0,0,0,0,1);
            DisplayFx.particle(p,"minecraft:cloud",center.add(0,3,0),8,3,8,.2,90);
            DestructionManager.queueDisc(p,p.serverLevel(),WorldOps.block(center),7,1);
        });
    }

    private static void flameDragon(ServerPlayer p){
        PowerState.setAction(p,405,120);
        ServerLevel level=p.serverLevel();
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.DRAGON_ROAR,SoundSource.PLAYERS,4.0f,.48f);
        for(int t=0;t<54;t+=3){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()->{
                Vec3 look=WorldOps.safeLook(p);
                Vec3 flat=new Vec3(look.x,0,look.z);
                if(flat.lengthSqr()<.001) flat=new Vec3(0,0,1);
                flat=flat.normalize();
                Vec3 right=WorldOps.right(flat);
                Vec3 base=p.position().add(look.scale(3.0)).add(0,2.2,0);
                double mantle=2.7+ft*.055;
                // A second, fiery serpentine silhouette grows around the already-large dragon body.
                for(int i=0;i<12;i++){
                    double wave=Math.sin(ft*.13-i*.62)*mantle*.44;
                    Vec3 spine=base.subtract(flat.scale(i*2.15)).add(right.scale(wave))
                            .add(0,Math.cos(ft*.09-i*.45)*.48-i*.035,0);
                    DisplayFx.particle(p,"minecraft:flame",spine,mantle*.36,mantle*.25,mantle*.36,.055,8);
                    DisplayFx.particle(p,"minecraft:large_smoke",spine,mantle*.24,mantle*.18,mantle*.24,.018,3);
                    if(ft%9==0 && (i&1)==0) DisplayFx.shard(p,spine,"minecraft:magma_block",.52,.52,1.8,
                            DisplayFx.yaw(flat),DisplayFx.pitch(look),12,"glq_flame_mantle");
                }
                if ((ft & 7) == 0) DisplayFx.pressureRing(p,base,look,mantle+1.4,14,
                        "minecraft:orange_stained_glass",8,"glq_flame_heat");
            });
        }
        CinematicScheduler.schedule(p, 58,()->{
            Vec3 l=WorldOps.safeLook(p);
            WorldOps.move(p,l.scale(2.6).add(0,.4,0),false);
            for(int s=1;s<=6;s++){
                final int n=s;
                CinematicScheduler.schedule(p, n*3,()->{
                    Vec3 c=p.position().add(WorldOps.safeLook(p).scale(n*4.8)).add(0,1.8,0);
                    WorldOps.damageSphere(p,c,6.0+n*.5,8.0f+n*2.0f,1.5+n*.2);
                    DisplayFx.particle(p,"minecraft:flame",c,4.5,2.0,4.5,.16,55);
                    DisplayFx.particle(p,"minecraft:large_smoke",c,3.0,1.7,3.0,.08,28);
                    DestructionManager.queueSphere(p,level,WorldOps.block(c),Math.min(7,3+n/2));
                    WorldOps.igniteSurface(p,c,Math.min(6,3+n/2));
                });
            }
        });
    }
}
