package dev.openai.grandline.ability;

import dev.openai.grandline.registry.ModSounds;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.visual.DisplayFx;
import dev.openai.grandline.visual.FractureFx;
import dev.openai.grandline.world.DestructionManager;
import dev.openai.grandline.world.WorldOps;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Five deliberately different quake techniques: contact hypocenter, broken-air lane, ground event,
 * radial interception, and battlefield-scale displacement. None are implemented as vanilla explosions. */
public final class GuraAbilities {
    private GuraAbilities() {}

    public static void activate(ServerPlayer player, int slot) {
        switch (slot) {
            case 1 -> hypocenter(player);
            case 2 -> airBreak(player);
            case 3 -> seaquake(player);
            case 4 -> repulsion(player);
            case 5 -> worldShaker(player);
            default -> { }
        }
    }

    /** Shingen no Ichigeki-inspired concentrated quake sphere and close-range directional punch. */
    private static void hypocenter(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        PowerState.setAction(p,101,22);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.GURA_CHARGE,SoundSource.PLAYERS,1.6f,.86f);

        for(int t=0;t<=12;t+=2){
            final int ft=t;
            CinematicScheduler.schedule(p, t,()->{
                Vec3 look=WorldOps.safeLook(p);
                Vec3 hand=p.getEyePosition().add(look.scale(.68)).add(WorldOps.right(look).scale(.34)).add(0,-.34,0);
                double r=.22+ft*.032;
                // Three different orbits prevent the sphere from reading as a single flat white ball.
                for(int orbit=0;orbit<3;orbit++){
                    for(int i=0;i<4;i++){
                        double a=ft*.31+Math.PI*2*i/4.0+orbit*.57;
                        Vec3 off=switch(orbit){
                            case 0 -> new Vec3(Math.cos(a)*r,Math.sin(a)*r*.34,Math.sin(a)*r);
                            case 1 -> new Vec3(Math.cos(a)*r*.42,Math.sin(a)*r,Math.sin(a)*r);
                            default -> new Vec3(Math.cos(a)*r,Math.sin(a)*r,Math.sin(a)*r*.35);
                        };
                        Vec3 orb=hand.add(off);
                        DisplayFx.shard(p,orb,(i+orbit)%2==0?"minecraft:sea_lantern":"minecraft:white_stained_glass",
                                .055,.055,.15,(float)Math.toDegrees(a),0,5,"glq_hypo_orbit");
                    }
                }
                DisplayFx.particle(p,"minecraft:end_rod",hand,.18,.18,.18,.006,6);
                if(ft%4==0){
                    DisplayFx.pressureShell(p,hand,look,r*1.48,"minecraft:white_stained_glass",5,"glq_hypo_shell");
                    // Microfractures make the held point feel structurally unstable before release.
                    FractureFx.plane(p,hand.add(look.scale(.08)),look,Math.max(.65,r*1.35),503+ft);
                }
            });
        }

        CinematicScheduler.schedule(p, 14,()->{
            Vec3 l=WorldOps.safeLook(p);
            Vec3 from=p.getEyePosition().add(l.scale(.62));
            Vec3 impact=p.getEyePosition().add(l.scale(2.8));
            // Readable hand -> target energy transfer, then a compact spatial rupture.
            for(int i=1;i<=5;i++){
                Vec3 node=from.add(l.scale(i*.38));
                DisplayFx.pressureRing(p,node,l,.30+i*.11,8,"minecraft:white_stained_glass",5,"glq_hypo_transfer");
            }
            level.playSound(null,impact.x,impact.y,impact.z,ModSounds.GURA_IMPACT,SoundSource.PLAYERS,2.2f,.76f);
            WorldOps.damageCone(p,from,l,7.5,3.1,18f,2.4);
            FractureFx.plane(p,impact,l,4.6,(int)level.getGameTime());
            DisplayFx.pressureRing(p,impact,l,3.1,18,"minecraft:white_stained_glass",10,"glq_hypo_impact_ring");
            DisplayFx.particle(p,"minecraft:poof",impact,1.8,.8,1.8,.13,48);
            DestructionManager.queueSphere(p,level,WorldOps.block(impact),3);
        });
    }

    /** Kaishin/Gekishin language adapted as a medium-long lane whose visual crack lingers in space. */
    private static void airBreak(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        PowerState.setAction(p,102,34);
        Vec3 initialLook=WorldOps.safeLook(p);
        Vec3 origin=p.getEyePosition().add(initialLook.scale(1.35));
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.GURA_CRACK,SoundSource.PLAYERS,2.0f,.92f);

        // Crack forms in readable stages before the actual shock front runs beyond it.
        for(int phase=0;phase<3;phase++){
            final int f=phase;
            CinematicScheduler.schedule(p, f*3,()-> FractureFx.plane(p,origin.add(initialLook.scale(f*.42)),initialLook,
                    2.8+f*2.7,(int)level.getGameTime()+17+f*41));
        }
        CinematicScheduler.schedule(p, 7,()-> DisplayFx.pressureRing(p,origin,initialLook,4.2,18,
                "minecraft:white_stained_glass",9,"glq_airbreak_release"));

        for(int step=1;step<=9;step++){
            final int s=step;
            CinematicScheduler.schedule(p, 7+s*2,()->{
                Vec3 c=origin.add(initialLook.scale(s*4.0));
                WorldOps.damageSphere(p,c,3.0+s*.07,6.6f+s*.35,1.05);
                DisplayFx.particle(p,"minecraft:cloud",c,1.8,.8,1.8,.08,20);
                if((s&1)==0) DisplayFx.pressureRing(p,c,initialLook,1.8+s*.13,10,
                        "minecraft:white_stained_glass",6,"glq_airbreak_front");
                if(s==4 || s==8) DestructionManager.queueDisc(p,level,WorldOps.block(c),2,1);
            });
        }
    }

    /** Terrain-transmitted quake. Damage, loss of footing, visual debris and real edits travel in stages. */
    private static void seaquake(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        PowerState.setAction(p,103,52);
        Vec3 look=WorldOps.safeLook(p);
        Vec3 flat=new Vec3(look.x,0,look.z);
        if(flat.lengthSqr()<.001) flat=new Vec3(0,0,1);
        flat=flat.normalize();
        Vec3 right=WorldOps.right(flat);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.GURA_RUMBLE,SoundSource.PLAYERS,2.3f,.62f);

        Vec3 start=p.position().add(flat.scale(1.2));
        for(int stage=1;stage<=10;stage++){
            final int s=stage;
            final Vec3 dir=flat;
            final Vec3 side=right;
            CinematicScheduler.schedule(p, s*3,()->{
                // Alternating lateral offset creates a torn fault line rather than a row of circles.
                double zig=(s%2==0?1:-1)*(1.0+s*.09);
                Vec3 c=start.add(dir.scale(2.6*s)).add(side.scale(zig));
                Vec3 ground=new Vec3(c.x,Math.floor(c.y),c.z);
                WorldOps.damageSphere(p,ground.add(0,1,0),3.7+s*.17,4.2f+s*.42,1.0+s*.035);
                WorldOps.radialImpulse(p,ground.add(0,.4,0),3.8+s*.15,.25+s*.055);
                DisplayFx.particle(p,"minecraft:poof",ground.add(0,.35,0),2.4,.35,2.4,.25,30);
                DisplayFx.particle(p,"minecraft:large_smoke",ground.add(0,.5,0),2.0,.3,2.0,.03,12);
                if((s&1)==0) FractureFx.plane(p,ground.add(0,.32,0),new Vec3(0,1,0),3.2+s*.12,113+s);
                DestructionManager.queueDisc(p,level,WorldOps.block(ground),Math.min(4,2+s/3),1);
                if(s>1){
                    Vec3 previous=start.add(dir.scale(2.6*(s-1))).add(side.scale((s%2!=0?1:-1)*(1.0+(s-1)*.09)));
                    DestructionManager.queueLine(p,level,WorldOps.block(previous),WorldOps.block(ground),1);
                }
            });
        }
    }

    /** Radial interception: mechanically defensive, disrupts projectiles, repels entities and chips terrain. */
    private static void repulsion(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        PowerState.setAction(p,104,22);
        Vec3 c=p.position().add(0,1,0);
        level.playSound(null,c.x,c.y,c.z,ModSounds.GURA_CRACK,SoundSource.PLAYERS,2.1f,1.18f);
        FractureFx.shell(p,c,4.8,(int)level.getGameTime()+91);
        for(int ring=1;ring<=3;ring++){
            final int r=ring;
            CinematicScheduler.schedule(p, r*2,()-> DisplayFx.pressureShell(p,c,new Vec3(0,1,0),1.5+r*1.25,
                    "minecraft:white_stained_glass",7,"glq_repulsion_shell"));
        }
        CinematicScheduler.schedule(p, 5,()->{
            WorldOps.discardProjectiles(p,9.5);
            WorldOps.damageSphere(p,c,7.0,7f,2.9);
            WorldOps.radialImpulse(p,c,10.0,2.0);
            DisplayFx.particle(p,"minecraft:cloud",c,4.0,2.2,4.0,.14,76);
            // Small local actual damage only; the role remains interception, not another crater attack.
            DestructionManager.queueDisc(p,level,WorldOps.block(p.position()),2,0);
        });
    }

    /** Shima Yurashi-inspired battlefield displacement: directional faults + staged aftershocks, not a giant explosion. */
    private static void worldShaker(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        PowerState.setAction(p,105,96);
        Vec3 origin=p.position().add(0,1.1,0);
        Vec3 look=WorldOps.safeLook(p);
        Vec3 flat=new Vec3(look.x,0,look.z);
        if(flat.lengthSqr()<.001) flat=new Vec3(0,0,1);
        flat=flat.normalize();
        Vec3 right=WorldOps.right(flat);
        level.playSound(null,p.getX(),p.getY(),p.getZ(),ModSounds.GURA_RUMBLE,SoundSource.PLAYERS,3.5f,.46f);

        // The "grab" grows spatially around the user's hands/world before release.
        for(int charge=0;charge<5;charge++){
            final int c=charge;
            CinematicScheduler.schedule(p, c*7,()->{
                Vec3 pt=p.position().add(0,1.1,0);
                FractureFx.shell(p,pt,2.8+c*1.35,531+c);
                DisplayFx.pressureRing(p,pt,flat,2.2+c*1.25,14,"minecraft:white_stained_glass",8,"glq_world_grab");
                DisplayFx.particle(p,"minecraft:cloud",pt,2+c,1.0+c*.4,2+c,.04,20+c*7);
            });
        }

        CinematicScheduler.schedule(p, 36,()->{
            Vec3 center=p.position();
            level.playSound(null,center.x,center.y,center.z,ModSounds.GURA_IMPACT,SoundSource.PLAYERS,4.0f,.52f);
            DisplayFx.particle(p,"minecraft:flash",center.add(0,1,0),0,0,0,0,1);

            // Six long, asymmetric rupture rays sell the idea that the battlefield was seized and shifted.
            for(int ray=0;ray<6;ray++){
                double spread=(ray-2.5)*.31;
                Vec3 dir=flat.scale(Math.cos(spread)).add(right.scale(Math.sin(spread))).normalize();
                if(ray>=4) dir=dir.scale(-1);
                Vec3 end=center.add(dir.scale(19+ray*2.2));
                DestructionManager.queueLine(p,level,WorldOps.block(center),WorldOps.block(end),ray%3==0?2:1);
            }

            for(int wave=1;wave<=6;wave++){
                final int w=wave;
                CinematicScheduler.schedule(p, w*5,()->{
                    double rad=4+w*4.0;
                    WorldOps.damageSphere(p,center,rad,4.5f+w*1.9f,1.0+w*.32);
                    for(int i=0;i<12;i++){
                        double a=Math.PI*2*i/12.0+w*.23;
                        // Deliberately elliptical/asymmetric front rather than a uniform blast ring.
                        double rx=rad*(.80+.25*Math.abs(Math.cos(a)));
                        Vec3 edge=center.add(Math.cos(a)*rx,.35+((i+w)%3)*.16,Math.sin(a)*rad*.72);
                        DisplayFx.particle(p,"minecraft:cloud",edge,1.5,.75,1.5,.11,14);
                        if(i%3==0) FractureFx.plane(p,edge,new Vec3(Math.cos(a),.16,Math.sin(a)),3.4+w*.18,700+w*31+i);
                    }
                    if(w<=4){
                        Vec3 faultCenter=center.add(flat.scale((w-2)*3.4)).add(right.scale((w%2==0?1:-1)*2.8));
                        DestructionManager.queueDisc(p,level,WorldOps.block(faultCenter),Math.min(4+w,9),1);
                    }
                });
            }

            // Delayed low-frequency aftershocks are part of the aftermath rather than one instant hit.
            for(int a=0;a<3;a++){
                final int after=a;
                CinematicScheduler.schedule(p, 42+a*10,()->{
                    Vec3 c=center.add(flat.scale((after-1)*7.0)).add(right.scale((after%2==0?1:-1)*4.0));
                    level.playSound(null,c.x,c.y,c.z,ModSounds.GURA_RUMBLE,SoundSource.PLAYERS,1.9f,.48f+after*.05f);
                    WorldOps.damageSphere(p,c,6.0,3.5f,1.0);
                    DisplayFx.particle(p,"minecraft:poof",c.add(0,.4,0),3.5,.8,3.5,.11,34);
                });
            }
        });
    }
}
