package dev.openai.grandline.ability;

import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;

public final class AbilityCatalog {
    private AbilityCatalog() {}

    private static final AbilityDefinition[] GURA = {
        null,
        a("Hypocenter / Quake Fist", "Hypocenter", 120, 10, 0xFFE9F8FF, "Q"),
        a("Shattering Void / Air Break", "Air Break", 180, 16, 0xFFD6F3FF, "V"),
        a("Seaquake / Ground Rupture", "Seaquake", 260, 22, 0xFFB7E5FF, "S"),
        a("Seismic Defense / Quake Repulsion", "Repulsion", 300, 20, 0xFFFFFFFF, "R"),
        a("World Shaker / Shima Yurashi", "World Shaker", 1200, 65, 0xFFF2FCFF, "W")
    };

    private static final AbilityDefinition[] BASE = {
        null,
        a("Azure Claw", "Azure Claw", 70, 8, 0xFF55D8FF, "C"),
        a("Scale Bastion", "Scale Bastion", 240, 14, 0xFF2D9CCC, "B"),
        a("Flame Cloud Step", "Cloud Step", 100, 10, 0xFFFF7FA6, "F"),
        a("Dragon Pulse", "Dragon Pulse", 200, 18, 0xFF4FD2FF, "P"),
        a("Hybrid Transformation", "Hybrid", 600, 40, 0xFFE12B42, "H")
    };

    private static final AbilityDefinition[] HYBRID = {
        null,
        a("Thunder Bagua", "Thunder Bagua", 180, 18, 0xFFDE1838, "T"),
        a("Kundali Dragon Swarm", "Kundali Swarm", 260, 24, 0xFF8B1225, "K"),
        a("Hybrid Dragon Breath", "Dragon Breath", 160, 18, 0xFFFF6D32, "B"),
        a("Vajra Shockwave", "Vajra", 220, 20, 0xFFCA2745, "V"),
        a("Full Dragon Transformation", "Full Dragon", 900, 55, 0xFF35C8FF, "D")
    };

    private static final AbilityDefinition[] DRAGON = {
        null,
        a("Dragon Rush / Coil Assault", "Dragon Rush", 160, 18, 0xFF3ACBFF, "R"),
        a("Kaifu / Demolition Gust", "Kaifu", 180, 20, 0xFF91EEFF, "K"),
        a("Tatsumaki / Dragon Twister", "Tatsumaki", 320, 30, 0xFF62BDE9, "T"),
        a("Tatsumaki Kaifu", "Storm Kaifu", 500, 42, 0xFFB7F4FF, "S"),
        a("Kaen Daiko / Flame Dragon", "Flame Dragon", 1600, 80, 0xFFFF562E, "F")
    };

    private static AbilityDefinition a(String n, String s, int cd, int energy, int color, String glyph) {
        return new AbilityDefinition(n, s, cd, energy, color, glyph);
    }

    public static AbilityDefinition get(FruitPower fruit, DragonForm form, int slot) {
        if (slot < 1 || slot > 5) return null;
        if (fruit == FruitPower.GURA) return GURA[slot];
        if (fruit != FruitPower.SEIRYU) return null;
        return switch (form) {
            case HUMAN -> BASE[slot];
            case HYBRID -> HYBRID[slot];
            case DRAGON -> DRAGON[slot];
        };
    }
}
