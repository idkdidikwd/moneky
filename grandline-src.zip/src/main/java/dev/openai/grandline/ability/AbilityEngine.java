package dev.openai.grandline.ability;

import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.visual.DisplayFx;
import dev.openai.grandline.visual.TransformationRigManager;
import dev.openai.grandline.world.DestructionManager;
import dev.openai.grandline.world.DragonController;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class AbilityEngine {
    private static final Map<UUID,Integer> CONTROLS=new HashMap<>();

    private AbilityEngine() {}

    public static void initialize(){
        ServerTickEvents.END_SERVER_TICK.register(server->{
            CinematicScheduler.tick();
            DestructionManager.tick();
            for(ServerPlayer p:server.getPlayerList().getPlayers()) tickPlayer(p);
        });
        AttackEntityCallback.EVENT.register((player,level,hand,entity,hitResult)->{
            if(player instanceof ServerPlayer sp) {
                if (TransformationRigManager.redirectHit(sp, entity)) return InteractionResult.SUCCESS;
                if(PowerState.fruit(sp)==FruitPower.SEIRYU
                        && PowerState.form(sp)==DragonForm.HUMAN && sp.getMainHandItem().isEmpty()){
                    SeiryuAbilities.passiveClaw(sp);
                }
            }
            return InteractionResult.PASS;
        });
        AttackBlockCallback.EVENT.register((player,level,hand,pos,direction)->{
            if(player instanceof ServerPlayer sp
                    && hand==InteractionHand.MAIN_HAND
                    && !sp.isSpectator()
                    && PowerState.fruit(sp)==FruitPower.SEIRYU
                    && PowerState.form(sp)==DragonForm.HUMAN
                    && sp.getMainHandItem().isEmpty()) {
                SeiryuAbilities.passiveClawBlock(sp,pos,direction);
            }
            return InteractionResult.PASS;
        });
        ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register((player, origin, destination) -> {
            // Cancel any world-bound cinematic stages before they can edit the old level after a portal/teleport.
            CONTROLS.remove(player.getUUID());
            CinematicScheduler.cancel(player.getUUID());
            DestructionManager.cancelSource(player.getUUID());
            DisplayFx.clearOwner(player);
            TransformationRigManager.clearAll(player);
            DragonController.reset(player);
            PowerState.setAction(player, 0, 0);
            // Persistent fruit/form data remains untouched. A transformed rig is rebuilt in the destination next tick.
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer,newPlayer,alive)->{
            if (!alive) {
                CONTROLS.remove(newPlayer.getUUID());
                CinematicScheduler.cancel(newPlayer.getUUID());
                DestructionManager.cancelSource(newPlayer.getUUID());
                DisplayFx.clearOwner(newPlayer);
                TransformationRigManager.clearAll(newPlayer);
                PowerState.setForm(newPlayer,DragonForm.HUMAN);
                PowerState.setAction(newPlayer,0,0);
            }
        });
        ServerPlayConnectionEvents.JOIN.register((handler,sender,server)->{
            ServerPlayer p=handler.getPlayer();
            // A clean owner tag namespace on every login prevents saved/stale display rigs from
            // duplicating after reconnects or an interrupted previous session. Form data itself persists.
            CONTROLS.remove(p.getUUID());
            CinematicScheduler.cancel(p.getUUID());
            DestructionManager.cancelSource(p.getUUID());
            DisplayFx.clearOwner(p);
            TransformationRigManager.clearAll(p);
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->{
            ServerPlayer p=handler.getPlayer();
            CONTROLS.remove(p.getUUID());
            CinematicScheduler.cancel(p.getUUID());
            DestructionManager.cancelSource(p.getUUID());
            DisplayFx.clearOwner(p);
            TransformationRigManager.clearAll(p);
            DragonController.reset(p);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            // Integrated servers can stop and a new world can start in the same JVM. Never carry
            // scheduled edits, transformed rigs, breath locks, or input state into that next world.
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                DisplayFx.clearOwner(p);
                TransformationRigManager.clearAll(p);
                DragonController.reset(p);
            }
            CONTROLS.clear();
            CinematicScheduler.clear();
            DestructionManager.clear();
            DragonController.clearState();
        });
    }

    private static void tickPlayer(ServerPlayer p){
        FruitPower fruit=PowerState.fruit(p);
        if(fruit==FruitPower.NONE) {
            TransformationRigManager.remove(p);
            DragonController.reset(p);
            CONTROLS.remove(p.getUUID());
            return;
        }

        int actionTicks=PowerState.actionTicks(p);
        if(actionTicks>0) PowerState.setAction(p,PowerState.action(p),actionTicks-1);
        else if(PowerState.action(p)!=0) PowerState.setAction(p,0,0);

        if(PowerState.energy(p)<100 && p.tickCount%8==0 && !(fruit==FruitPower.SEIRYU && PowerState.form(p)==DragonForm.DRAGON
                && (CONTROLS.getOrDefault(p.getUUID(),0)&DragonController.ATTACK)!=0)){
            PowerState.setEnergy(p,PowerState.energy(p)+1);
        }

        if(fruit==FruitPower.SEIRYU){
            DragonForm form=PowerState.form(p);
            TransformationRigManager.tick(p);
            if(form==DragonForm.DRAGON) DragonController.tick(p,CONTROLS.getOrDefault(p.getUUID(),0));
            else DragonController.reset(p);
        } else {
            TransformationRigManager.remove(p);
            DragonController.reset(p);
        }
    }

    public static void tryActivate(ServerPlayer p,int slot){
        FruitPower fruit=PowerState.fruit(p);
        if(fruit==FruitPower.NONE || slot<1 || slot>5) return;
        DragonForm form=PowerState.form(p);
        // No sixth combat bind is needed: crouch + slot 5 deliberately steps Seiryu back one form.
        // This keeps Dragon from becoming a permanent trap while preserving slot 5 as its ultimate normally.
        if (fruit==FruitPower.SEIRYU && slot==5 && form!=DragonForm.HUMAN && p.isShiftKeyDown()) {
            if (PowerState.actionTicks(p)<=0) SeiryuAbilities.revertForm(p, form);
            return;
        }
        AbilityDefinition def=AbilityCatalog.get(fruit,form,slot);
        if(def==null) return;

        long now=p.serverLevel().getGameTime();
        long end=PowerState.cooldownEnd(p,slot);
        if(now<end){
            long remain=(end-now+19)/20;
            p.sendSystemMessage(Component.translatable("message.grandlinequakes.cooldown",remain));
            return;
        }
        if(PowerState.actionTicks(p)>0){
            p.sendSystemMessage(Component.translatable("message.grandlinequakes.busy"));
            return;
        }
        if(PowerState.energy(p)<def.energyCost()){
            p.sendSystemMessage(Component.translatable("message.grandlinequakes.no_energy"));
            return;
        }

        PowerState.setEnergy(p,PowerState.energy(p)-def.energyCost());
        long cooldown=Math.max(1L,Math.round(def.cooldownTicks()*ModConfig.cooldownMultiplier));
        PowerState.setCooldownEnd(p,slot,now+cooldown);
        if(fruit==FruitPower.GURA) GuraAbilities.activate(p,slot);
        else SeiryuAbilities.activate(p,form,slot);
    }

    public static void updateControls(ServerPlayer p,int flags){
        if(PowerState.fruit(p)!=FruitPower.SEIRYU || PowerState.form(p)!=DragonForm.DRAGON){
            CONTROLS.remove(p.getUUID());
            return;
        }
        CONTROLS.put(p.getUUID(),flags&0x7f);
    }
}
