package dev.openai.grandline.ability;

public record AbilityDefinition(
        String name,
        String shortName,
        int cooldownTicks,
        int energyCost,
        int accentColor,
        String iconGlyph
) {
    public double cooldownSeconds() { return cooldownTicks / 20.0; }
}
