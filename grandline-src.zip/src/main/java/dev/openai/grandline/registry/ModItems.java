package dev.openai.grandline.registry;

import dev.openai.grandline.GrandLineQuakes;
import dev.openai.grandline.item.DevilFruitItem;
import dev.openai.grandline.state.FruitPower;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.Consumable;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.resources.ResourceKey;

import java.util.function.Function;

public final class ModItems {
    private static final FoodProperties DEVIL_FRUIT_FOOD = new FoodProperties.Builder().alwaysEdible().build();
    private static final Consumable DEVIL_FRUIT_CONSUMABLE = Consumables.defaultFood().build();

    public static final ResourceKey<Item> GURA_KEY = key("gura_gura_no_mi");
    public static final ResourceKey<Item> SEIRYU_KEY = key("uo_uo_no_mi_seiryu");

    public static final Item GURA_GURA_NO_MI = register(GURA_KEY,
            p -> new DevilFruitItem(FruitPower.GURA, p),
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).food(DEVIL_FRUIT_FOOD, DEVIL_FRUIT_CONSUMABLE));
    public static final Item UO_UO_NO_MI_SEIRYU = register(SEIRYU_KEY,
            p -> new DevilFruitItem(FruitPower.SEIRYU, p),
            new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).food(DEVIL_FRUIT_FOOD, DEVIL_FRUIT_CONSUMABLE));

    private ModItems() {}

    private static ResourceKey<Item> key(String path) {
        return ResourceKey.create(Registries.ITEM, GrandLineQuakes.id(path));
    }

    private static Item register(ResourceKey<Item> key, Function<Item.Properties, Item> factory, Item.Properties properties) {
        Item item = factory.apply(properties.setId(key));
        Registry.register(BuiltInRegistries.ITEM, key, item);
        return item;
    }

    public static void initialize() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(GURA_GURA_NO_MI);
            entries.accept(UO_UO_NO_MI_SEIRYU);
        });
    }
}
