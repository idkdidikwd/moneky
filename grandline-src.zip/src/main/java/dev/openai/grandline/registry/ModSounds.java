package dev.openai.grandline.registry;

import dev.openai.grandline.GrandLineQuakes;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    public static final SoundEvent GURA_CHARGE = register("gura_charge");
    public static final SoundEvent GURA_CRACK = register("gura_crack");
    public static final SoundEvent GURA_RUMBLE = register("gura_rumble");
    public static final SoundEvent GURA_IMPACT = register("gura_impact");
    public static final SoundEvent HAKI_CRACK = register("haki_crack");
    public static final SoundEvent DRAGON_ROAR = register("dragon_roar");
    public static final SoundEvent DRAGON_FLAME = register("dragon_flame");
    public static final SoundEvent DRAGON_FLAME_START = register("dragon_flame_start");
    public static final SoundEvent DRAGON_FLAME_END = register("dragon_flame_end");
    public static final SoundEvent DRAGON_WIND = register("dragon_wind");
    public static final SoundEvent TRANSFORM = register("transform");
    public static final SoundEvent FRUIT_AWAKEN = register("fruit_awaken");

    private ModSounds() {}
    private static SoundEvent register(String path) {
        Identifier id = GrandLineQuakes.id(path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }
    public static void initialize() {}
}
