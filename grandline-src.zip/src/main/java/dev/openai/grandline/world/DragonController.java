package dev.openai.grandline.world;

import dev.openai.grandline.registry.ModSounds;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.visual.DisplayFx;
import dev.openai.grandline.visual.TransformationRigManager;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-authoritative movement and held-primary-attack controller for Full Dragon. */
public final class DragonController {
    public static final int FORWARD=1, BACK=2, LEFT=4, RIGHT=8, UP=16, DOWN=32, ATTACK=64;
    private static final Set<UUID> BREATHING = new HashSet<>();
    /** Brief recovery prevents tap-spam from restarting the sustained sound/VFX every tick. */
    private static final Map<UUID, Integer> BREATH_LOCK = new HashMap<>();

    private DragonController() {}

    public static void tick(ServerPlayer player, int flags) {
        player.setNoGravity(true);
        UUID id=player.getUUID();
        int lock=BREATH_LOCK.getOrDefault(id,0);
        if(lock>0) {
            lock--;
            if(lock==0) BREATH_LOCK.remove(id); else BREATH_LOCK.put(id,lock);
        }
        Vec3 look=WorldOps.safeLook(player);
        Vec3 horizontal=new Vec3(look.x,0,look.z);
        if(horizontal.lengthSqr()<.001) horizontal=new Vec3(0,0,1);
        horizontal=horizontal.normalize();
        Vec3 right=WorldOps.right(horizontal);
        Vec3 desired=Vec3.ZERO;
        if((flags&FORWARD)!=0) desired=desired.add(horizontal);
        if((flags&BACK)!=0) desired=desired.subtract(horizontal);
        if((flags&LEFT)!=0) desired=desired.subtract(right);
        if((flags&RIGHT)!=0) desired=desired.add(right);
        if((flags&UP)!=0) desired=desired.add(0,.82,0);
        if((flags&DOWN)!=0) desired=desired.add(0,-.72,0);
        if(desired.lengthSqr()>.001) desired=desired.normalize().scale(.76);

        // Heavy momentum: responsive enough to steer, but the long body still feels massive.
        Vec3 current=player.getDeltaMovement().scale(.82);
        Vec3 velocity=current.add(desired.scale(.22));
        if(velocity.length()>1.05) velocity=velocity.normalize().scale(1.05);
        player.setDeltaMovement(velocity);
        player.hurtMarked=true;
        player.resetFallDistance();

        boolean wantsBreath=(flags&ATTACK)!=0 && PowerState.energy(player)>0
                && PowerState.actionTicks(player)<=0 && BREATH_LOCK.getOrDefault(id,0)<=0;
        if(wantsBreath) {
            startBreath(player);
            breath(player);
        } else {
            stopBreath(player);
        }
    }

    public static boolean isBreathing(ServerPlayer player) {
        return BREATHING.contains(player.getUUID());
    }

    public static void clearState() {
        BREATHING.clear();
        BREATH_LOCK.clear();
    }

    public static void reset(ServerPlayer player) {
        stopBreath(player);
        BREATH_LOCK.remove(player.getUUID());
        player.setNoGravity(false);
    }

    private static void startBreath(ServerPlayer player) {
        if (!BREATHING.add(player.getUUID())) return;
        Vec3 mouth=TransformationRigManager.dragonMouth(player);
        player.serverLevel().playSound(null,mouth.x,mouth.y,mouth.z,
                ModSounds.DRAGON_FLAME_START, SoundSource.PLAYERS,2.8f,.72f);
        DisplayFx.pressureRing(player,mouth,WorldOps.safeLook(player),.8,10,
                "minecraft:orange_stained_glass",9,"glq_breath_start");
    }

    private static void stopBreath(ServerPlayer player) {
        UUID id=player.getUUID();
        if (!BREATHING.remove(id)) return;
        // Normal release has a short recovery; exhausting the heat/energy reserve is costlier.
        BREATH_LOCK.put(id,PowerState.energy(player)<=2?24:10);
        Vec3 mouth=TransformationRigManager.dragonMouth(player);
        player.serverLevel().playSound(null,mouth.x,mouth.y,mouth.z,
                ModSounds.DRAGON_FLAME_END, SoundSource.PLAYERS,2.0f,.82f);
        DisplayFx.particle(player,"minecraft:large_smoke",mouth,.7,.5,.7,.025,12);
    }

    private static void breath(ServerPlayer player) {
        if(PowerState.energy(player)<=0) {
            stopBreath(player);
            return;
        }
        if(player.tickCount%2==0) PowerState.setEnergy(player,PowerState.energy(player)-1);
        Vec3 look=WorldOps.safeLook(player);
        Vec3 mouth=TransformationRigManager.dragonMouth(player);
        WorldOps.igniteCone(player,mouth,look,34,7.0,player.tickCount%4==0?5.0f:1.0f,5);

        if(player.tickCount%2==0) {
            // Structured breath: bright core, expanding flame body, smoke/heat shell, and wind rings.
            for(int d=2;d<=30;d+=4){
                Vec3 p=mouth.add(look.scale(d));
                double width=.25+d*.105;
                DisplayFx.particle(player,"minecraft:flame",p,width,width*.55,width,.02,16);
                DisplayFx.particle(player,"minecraft:smoke",p,width*.70,width*.45,width*.70,.015,5);
                if((d&7)==2) DisplayFx.particle(player,"minecraft:end_rod",p,width*.28,width*.18,width*.28,.012,2);
            }
        }
        if(player.tickCount%6==0) {
            double r=.9+(player.tickCount%18)/18.0*1.8;
            DisplayFx.pressureRing(player,mouth.add(look.scale(1.6)),look,r,12,
                    "minecraft:orange_stained_glass",7,"glq_breath_ring");
        }
        if(player.tickCount%8==0) {
            player.serverLevel().playSound(null,player.getX(),player.getY(),player.getZ(),
                    ModSounds.DRAGON_FLAME, SoundSource.PLAYERS,2.4f,.72f);
            // Sustained breath really scars the impact zone, but uses the same staged griefing budget.
            Vec3 impact=mouth.add(look.scale(28.0));
            DestructionManager.queueDisc(player,player.serverLevel(),WorldOps.block(impact),2,1);
            WorldOps.igniteSurface(player, impact, 3);
        }
    }
}
