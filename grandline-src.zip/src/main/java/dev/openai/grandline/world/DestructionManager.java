package dev.openai.grandline.world;

import dev.openai.grandline.GrandLineQuakes;
import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.api.DestructionProtectionCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.FallingBlock;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;

/**
 * Staged, server-authoritative terrain edits. Gameplay can enqueue a dramatic shape immediately;
 * the world is mutated over later ticks with chunk, block-entity, fluid, hardness and queue caps.
 * Visual destruction is deliberately handled elsewhere so disabling griefing does not remove VFX.
 */
public final class DestructionManager {
    private static final Queue<Job> QUEUE = new ArrayDeque<>();
    private static final Set<String> DEDUPE = new HashSet<>();
    private static long droppedForCap;
    private static long lastCapWarningTick = Long.MIN_VALUE;

    private DestructionManager() {}

    public static void queueSphere(ServerPlayer source, ServerLevel level, BlockPos center, int radius) {
        if (!ModConfig.terrainDestruction || radius <= 0) return;
        radius = Math.min(radius, ModConfig.maxDestructionRadius);
        int r2 = radius * radius;
        for (int y = -radius; y <= radius; y++) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    int d2 = x*x + y*y + z*z;
                    if (d2 > r2) continue;
                    // Crater/shell profile. Catastrophic visually, but avoids blindly deleting a full cube.
                    if (d2 < Math.max(0, r2 - radius * 3) && y < 0) continue;
                    queue(source, level, center.offset(x, y, z));
                }
            }
        }
    }

    public static void queueDisc(ServerPlayer source, ServerLevel level, BlockPos center, int radius, int depth) {
        if (!ModConfig.terrainDestruction) return;
        radius = Math.min(radius, ModConfig.maxDestructionRadius);
        for (int y = 0; y >= -Math.max(0, depth); y--) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x*x + z*z <= radius*radius) queue(source, level, center.offset(x, y, z));
                }
            }
        }
    }

    /** Directional rupture path used by seismic lines and cutting-wind terrain slices. */
    public static void queueLine(ServerPlayer source, ServerLevel level, BlockPos from, BlockPos to, int radius) {
        if (!ModConfig.terrainDestruction) return;
        int dx = to.getX() - from.getX();
        int dy = to.getY() - from.getY();
        int dz = to.getZ() - from.getZ();
        int steps = Math.max(1, Math.max(Math.abs(dx), Math.max(Math.abs(dy), Math.abs(dz))));
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            BlockPos p = BlockPos.containing(from.getX() + dx*t, from.getY() + dy*t, from.getZ() + dz*t);
            queueDisc(source, level, p, Math.max(1, radius), 1);
        }
    }

    public static void queue(ServerPlayer source, ServerLevel level, BlockPos pos) {
        if (!ModConfig.terrainDestruction) return;
        if (QUEUE.size() >= ModConfig.maxQueuedBlocks) {
            droppedForCap++;
            long now = level.getGameTime();
            if (now - lastCapWarningTick >= 200) {
                lastCapWarningTick = now;
                GrandLineQuakes.LOGGER.warn("Destruction work queue reached cap {} ({} edits discarded since last warning)",
                        ModConfig.maxQueuedBlocks, droppedForCap);
                droppedForCap = 0;
            }
            return;
        }
        String key = level.dimension().identifier() + ":" + pos.asLong();
        if (DEDUPE.add(key)) QUEUE.add(new Job(source.getUUID(), level, pos, key));
    }

    public static void tick() {
        int budget = ModConfig.blocksPerTick;
        while (budget-- > 0 && !QUEUE.isEmpty()) {
            Job job = QUEUE.poll();
            DEDUPE.remove(job.key());

            // Never force-load a chunk because an ultimate happened to reach its coordinates.
            if (!job.level().hasChunkAt(job.pos())) continue;
            // Containers/spawners/etc. are intentionally left alone to avoid corrupting block entities.
            if (job.level().getBlockEntity(job.pos()) != null) continue;
            var state = job.level().getBlockState(job.pos());
            if (state.isAir()) continue;
            // Water/lava remain stable; visual debris handles spectacle around shorelines.
            if (!state.getFluidState().isEmpty()) continue;
            float hardness = state.getDestroySpeed(job.level(), job.pos());
            if (hardness < 0.0f) continue; // bedrock/barrier-style unbreakable blocks
            // Do not remove the support below a gravity block during a large queued rupture. This
            // prevents one edit from fan-out spawning an uncontrolled column of FallingBlockEntity
            // instances. A falling block that is itself queued can still be removed normally.
            var above = job.level().getBlockState(job.pos().above());
            if (above.getBlock() instanceof FallingBlock) continue;
            // Compatibility point for claims/protection mods. A single veto preserves the block.
            if (!DestructionProtectionCallback.EVENT.invoker().allow(job.sourceId(), job.level(), job.pos(), state)) continue;
            job.level().destroyBlock(job.pos(), false);
        }
    }

    /** Cancel queued terrain edits owned by one player. This is used when that player leaves or
     * changes dimension so a delayed ultimate cannot keep mutating a level they are no longer in. */
    public static void cancelSource(UUID sourceId) {
        if (sourceId == null || QUEUE.isEmpty()) return;
        QUEUE.removeIf(job -> {
            if (!job.sourceId().equals(sourceId)) return false;
            DEDUPE.remove(job.key());
            return true;
        });
    }

    public static void clear() {
        QUEUE.clear();
        DEDUPE.clear();
        droppedForCap = 0L;
        lastCapWarningTick = Long.MIN_VALUE;
    }

    public static int queuedBlocks() { return QUEUE.size(); }
    private record Job(UUID sourceId, ServerLevel level, BlockPos pos, String key) { }
}
