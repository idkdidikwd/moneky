package dev.openai.grandline.world;

import dev.openai.grandline.api.DestructionProtectionCallback;
import dev.openai.grandline.config.ModConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.function.Predicate;

public final class WorldOps {
    private WorldOps() {}

    public static Vec3 safeLook(ServerPlayer player) {
        Vec3 look = player.getLookAngle();
        return look.lengthSqr() < 1.0e-6 ? new Vec3(0, 0, 1) : look.normalize();
    }

    public static Vec3 right(Vec3 look) {
        Vec3 r = look.cross(new Vec3(0, 1, 0));
        return r.lengthSqr() < 1.0e-6 ? new Vec3(1, 0, 0) : r.normalize();
    }

    public static List<LivingEntity> livingIn(ServerLevel level, Vec3 center, double radius, ServerPlayer source) {
        AABB box = new AABB(center.x - radius, center.y - radius, center.z - radius,
                center.x + radius, center.y + radius, center.z + radius);
        Predicate<LivingEntity> filter = e -> {
            if (e == source || !e.isAlive() || center.distanceToSqr(e.position()) > radius * radius) return false;
            if (e instanceof Player target) {
                // Always respect the server's PvP rules. With mod friendly-fire disabled, allied/team
                // players are additionally protected while enemy players remain valid combat targets.
                if (!source.canHarmPlayer(target)) return false;
                if (!ModConfig.friendlyFire && source.isAlliedTo(target)) return false;
            }
            return true;
        };
        return level.getEntitiesOfClass(LivingEntity.class, box, filter);
    }

    public static void damageSphere(ServerPlayer source, Vec3 center, double radius, float damage, double knockback) {
        ServerLevel level = source.serverLevel();
        for (LivingEntity target : livingIn(level, center, radius, source)) {
            target.hurtServer(level, source.damageSources().playerAttack(source), damage);
            if (knockback > 0) {
                Vec3 away = target.position().subtract(center);
                if (away.lengthSqr() < 1.0e-5) away = safeLook(source);
                away = away.normalize();
                target.push(away.x * knockback, Math.min(0.8, 0.15 + knockback * 0.12), away.z * knockback);
            }
        }
    }

    public static void damageCone(ServerPlayer source, Vec3 origin, Vec3 direction, double length, double radius, float damage, double knockback) {
        ServerLevel level = source.serverLevel();
        Vec3 dir = direction.normalize();
        Vec3 center = origin.add(dir.scale(length * 0.5));
        double search = length * 0.65 + radius;
        for (LivingEntity target : livingIn(level, center, search, source)) {
            Vec3 rel = target.getEyePosition().subtract(origin);
            double forward = rel.dot(dir);
            if (forward < 0 || forward > length) continue;
            Vec3 lateral = rel.subtract(dir.scale(forward));
            double allowed = radius * (0.35 + 0.65 * (forward / Math.max(1.0, length)));
            if (lateral.lengthSqr() > allowed * allowed) continue;
            target.hurtServer(level, source.damageSources().playerAttack(source), damage);
            target.push(dir.x * knockback, Math.min(0.65, knockback * 0.12), dir.z * knockback);
        }
    }

    public static void igniteCone(ServerPlayer source, Vec3 origin, Vec3 direction, double length, double radius, float damage, int fireSeconds) {
        ServerLevel level = source.serverLevel();
        Vec3 dir = direction.normalize();
        Vec3 center = origin.add(dir.scale(length * 0.5));
        for (LivingEntity target : livingIn(level, center, length * 0.7 + radius, source)) {
            Vec3 rel = target.getEyePosition().subtract(origin);
            double f = rel.dot(dir);
            if (f < 0 || f > length) continue;
            if (rel.subtract(dir.scale(f)).length() > radius * (0.4 + 0.6 * f / length)) continue;
            target.hurtServer(level, source.damageSources().playerAttack(source), damage);
            target.igniteForSeconds(fireSeconds);
            target.push(dir.x * 0.35, 0.08, dir.z * 0.35);
        }
    }

    public static BlockPos block(Vec3 p) { return BlockPos.containing(p.x, p.y, p.z); }

    /** Conservative server-side scorch/ignition pass. It never force-loads chunks and follows the
     * terrain-destruction switch so servers can keep the full visual breath without persistent fire. */
    public static void igniteSurface(ServerPlayer source, Vec3 center, int radius) {
        if (!ModConfig.terrainDestruction || radius <= 0) return;
        ServerLevel level = source.serverLevel();
        int r = Math.min(radius, Math.max(1, ModConfig.maxDestructionRadius));
        var fire = Blocks.FIRE.defaultBlockState();
        for (int x=-r; x<=r; x++) {
            for (int z=-r; z<=r; z++) {
                if (x*x + z*z > r*r || ((x*31 + z*17) & 1) != 0) continue;
                BlockPos start = BlockPos.containing(center.x + x, center.y + 2.0, center.z + z);
                if (!level.hasChunkAt(start)) continue;
                for (int dy=0; dy>=-6; dy--) {
                    BlockPos ground = start.offset(0,dy,0);
                    BlockPos firePos = ground.above();
                    var groundState = level.getBlockState(ground);
                    if (groundState.isAir() || !groundState.getFluidState().isEmpty()) continue;
                    var fireState = level.getBlockState(firePos);
                    if (!fireState.isAir()) break;
                    // Persistent fire is a world edit too: give the same protection/claim hook a veto
                    // before placing it, not only before destructive block removal.
                    if (fire.canSurvive(level, firePos)
                            && DestructionProtectionCallback.EVENT.invoker().allow(source.getUUID(), level, firePos, fireState)) {
                        level.setBlock(firePos, fire, 3);
                    }
                    break;
                }
            }
        }
    }

    public static void radialImpulse(ServerPlayer source, Vec3 center, double radius, double force) {
        for (LivingEntity e : livingIn(source.serverLevel(), center, radius, source)) {
            Vec3 d = e.position().subtract(center);
            if (d.lengthSqr() < 1.0e-6) d = new Vec3(0, 1, 0);
            d = d.normalize();
            e.push(d.x * force, 0.25 + Math.abs(d.y) * force * 0.2, d.z * force);
        }
    }

    /** Tangential + inward + upward acceleration for physical tornadoes. */
    public static void vortexImpulse(ServerPlayer source, Vec3 center, double radius, double swirl, double lift) {
        for (LivingEntity e : livingIn(source.serverLevel(), center, radius, source)) {
            Vec3 radial = e.position().subtract(center);
            Vec3 horizontal = new Vec3(radial.x,0,radial.z);
            if (horizontal.lengthSqr() < 1.0e-5) horizontal = new Vec3(1,0,0);
            horizontal = horizontal.normalize();
            Vec3 tangent = new Vec3(-horizontal.z,0,horizontal.x);
            double falloff = 1.0 - Math.min(1.0, Math.sqrt(radial.x*radial.x+radial.z*radial.z)/Math.max(1.0,radius));
            Vec3 impulse = tangent.scale(swirl*(.45+.55*falloff))
                    .subtract(horizontal.scale(.18+.22*falloff)).add(0,lift*(.55+.45*falloff),0);
            e.push(impulse.x, impulse.y, impulse.z);
        }
    }

    public static void move(ServerPlayer player, Vec3 velocity, boolean additive) {
        Vec3 base = additive ? player.getDeltaMovement() : Vec3.ZERO;
        player.setDeltaMovement(base.add(velocity));
        player.hurtMarked = true;
    }

    public static void discardProjectiles(ServerPlayer source, double radius) {
        Vec3 c = source.position();
        AABB box = new AABB(c.x-radius, c.y-radius, c.z-radius, c.x+radius, c.y+radius, c.z+radius);
        for (Projectile projectile : source.serverLevel().getEntitiesOfClass(Projectile.class, box, e -> true)) {
            // Do not erase the user's own shot, and avoid deleting unrelated projectiles merely
            // passing behind the field. Repulsion intercepts things actually moving toward the user
            // (or already dangerously close), which gives the defensive ability real spatial logic.
            if (projectile.getOwner() == source) continue;
            Vec3 toUser = c.subtract(projectile.position());
            double d2 = toUser.lengthSqr();
            Vec3 velocity = projectile.getDeltaMovement();
            boolean incoming = d2 <= 4.0 || (d2 > 1.0e-6 && velocity.dot(toUser.normalize()) > 0.05);
            if (incoming) projectile.discard();
        }
    }
}
