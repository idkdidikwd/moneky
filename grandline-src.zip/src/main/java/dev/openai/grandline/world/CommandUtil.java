package dev.openai.grandline.world;

import dev.openai.grandline.GrandLineQuakes;
import net.minecraft.server.level.ServerPlayer;

import java.util.concurrent.atomic.AtomicLong;

public final class CommandUtil {
    private static final AtomicLong FAILURES = new AtomicLong();

    private CommandUtil() {}

    public static void run(ServerPlayer player, String command) {
        try {
            player.getServer().getCommands().performPrefixedCommand(
                    player.createCommandSourceStack().withPermission(4), command);
        } catch (RuntimeException ex) {
            // Cosmetic VFX may fail without risking gameplay, but release QA still needs evidence.
            // Rate-limit warnings so a malformed effect cannot flood a dedicated-server log.
            long n = FAILURES.incrementAndGet();
            if (n <= 8 || n % 100 == 0) {
                GrandLineQuakes.LOGGER.warn("VFX command failed (failure #{}): {}", n, command, ex);
            }
        }
    }

    public static String f(double value) {
        return String.format(java.util.Locale.ROOT, "%.3f", value);
    }
}
