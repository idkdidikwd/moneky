package dev.openai.grandline.item;

import dev.openai.grandline.registry.ModSounds;
import dev.openai.grandline.state.DragonForm;
import dev.openai.grandline.state.FruitPower;
import dev.openai.grandline.state.PowerState;
import dev.openai.grandline.visual.DisplayFx;
import dev.openai.grandline.world.WorldOps;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class DevilFruitItem extends Item {
    private final FruitPower power;

    public DevilFruitItem(FruitPower power, Properties properties) {
        super(properties);
        this.power = power;
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int ticksRemaining) {
        super.onUseTick(level, entity, stack, ticksRemaining);
        if (!(entity instanceof ServerPlayer player) || !(level instanceof ServerLevel serverLevel)) return;
        if (PowerState.fruit(player) != FruitPower.NONE) return;

        int used = Math.max(0, getUseDuration(stack, entity) - ticksRemaining);
        if ((used & 3) != 0) return;
        Vec3 look = WorldOps.safeLook(player);
        Vec3 right = WorldOps.right(look);
        Vec3 hand = player.getEyePosition().add(look.scale(0.52)).add(right.scale(0.30)).add(0, -0.33, 0);
        double phase = used * 0.46;
        String block = power == FruitPower.GURA ? "minecraft:white_stained_glass" : "minecraft:cyan_stained_glass";
        for (int i = 0; i < 3; i++) {
            double a = phase + i * Math.PI * 2.0 / 3.0;
            Vec3 orb = hand.add(right.scale(Math.cos(a) * 0.24)).add(0, Math.sin(a) * 0.20, 0).add(look.scale(Math.sin(a * 0.7) * 0.08));
            DisplayFx.shard(player, orb, block, 0.07, 0.07, 0.16,
                    DisplayFx.yaw(look) + (float)Math.toDegrees(a), DisplayFx.pitch(look), 5, "glq_eat");
        }
        serverLevel.sendParticles(power == FruitPower.GURA ? ParticleTypes.END_ROD : ParticleTypes.SOUL_FIRE_FLAME,
                hand.x, hand.y, hand.z, 4, 0.10, 0.10, 0.10, 0.012);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!(entity instanceof ServerPlayer player) || !(level instanceof ServerLevel serverLevel)) {
            return super.finishUsingItem(stack, level, entity);
        }
        if (PowerState.fruit(player) != FruitPower.NONE) {
            player.sendSystemMessage(Component.translatable("message.grandlinequakes.already_bound"));
            return stack;
        }

        ItemStack result = super.finishUsingItem(stack, level, entity);
        PowerState.setFruit(player, power);
        PowerState.setForm(player, DragonForm.HUMAN);
        PowerState.setEnergy(player, 100);
        PowerState.setAction(player, 0, 0);
        for (int i = 1; i <= 5; i++) PowerState.setCooldownEnd(player, i, 0L);

        player.addEffect(new MobEffectInstance(MobEffects.NAUSEA, 90, 0, false, true, true));
        serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.FRUIT_AWAKEN,
                SoundSource.PLAYERS, 1.6f, power == FruitPower.GURA ? 0.72f : 1.05f);
        serverLevel.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0, player.getZ(),
                80, 0.7, 1.0, 0.7, 0.08);
        serverLevel.sendParticles(power == FruitPower.GURA ? ParticleTypes.END_ROD : ParticleTypes.SOUL_FIRE_FLAME,
                player.getX(), player.getY() + 1.0, player.getZ(), 48, 0.55, 0.9, 0.55, 0.025);
        for (int i = 0; i < 12; i++) {
            double a = Math.PI * 2.0 * i / 12.0;
            Vec3 pos = player.position().add(Math.cos(a) * 1.25, 0.25 + (i % 3) * 0.35, Math.sin(a) * 1.25);
            DisplayFx.shard(player, pos,
                    power == FruitPower.GURA ? "minecraft:sea_lantern" : "minecraft:cyan_concrete",
                    0.08, 0.08, 0.38, (float)Math.toDegrees(a), -18.0f, 18, "glq_awaken");
        }
        player.sendSystemMessage(Component.translatable(power == FruitPower.GURA
                ? "message.grandlinequakes.bound_gura" : "message.grandlinequakes.bound_seiryu"));
        return result;
    }
}
