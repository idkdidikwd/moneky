package dev.openai.grandline.config;

import dev.openai.grandline.GrandLineQuakes;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

public final class ModConfig {
    public enum VfxQuality { LOW, MEDIUM, HIGH, CINEMATIC }

    public static boolean terrainDestruction = true;
    public static int maxDestructionRadius = 18;
    public static int blocksPerTick = 72;
    public static int maxQueuedBlocks = 16000;
    public static VfxQuality vfxQuality = VfxQuality.HIGH;
    public static double cameraShake = 0.75;
    public static double dragonCameraDistance = 12.0;
    public static boolean friendlyFire = false;
    public static double cooldownMultiplier = 1.0;

    private ModConfig() {}

    public static void load() {
        Path file = FabricLoader.getInstance().getConfigDir().resolve("grandlinequakes.properties");
        Properties p = new Properties();
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file)) { p.load(r); }
            catch (IOException e) { GrandLineQuakes.LOGGER.warn("Could not read config", e); }
        }
        terrainDestruction = bool(p, "terrainDestruction", terrainDestruction);
        maxDestructionRadius = clamp(integer(p, "maxDestructionRadius", maxDestructionRadius), 0, 48);
        blocksPerTick = clamp(integer(p, "blocksPerTick", blocksPerTick), 8, 512);
        maxQueuedBlocks = clamp(integer(p, "maxQueuedBlocks", maxQueuedBlocks), 512, 100000);
        cameraShake = clamp(decimal(p, "cameraShake", cameraShake), 0.0, 1.5);
        dragonCameraDistance = clamp(decimal(p, "dragonCameraDistance", dragonCameraDistance), 4.0, 32.0);
        friendlyFire = bool(p, "friendlyFire", friendlyFire);
        cooldownMultiplier = clamp(decimal(p, "cooldownMultiplier", cooldownMultiplier), 0.25, 5.0);
        try { vfxQuality = VfxQuality.valueOf(p.getProperty("vfxQuality", vfxQuality.name()).toUpperCase(Locale.ROOT)); }
        catch (IllegalArgumentException ignored) {}

        p.setProperty("terrainDestruction", Boolean.toString(terrainDestruction));
        p.setProperty("maxDestructionRadius", Integer.toString(maxDestructionRadius));
        p.setProperty("blocksPerTick", Integer.toString(blocksPerTick));
        p.setProperty("maxQueuedBlocks", Integer.toString(maxQueuedBlocks));
        p.setProperty("vfxQuality", vfxQuality.name());
        p.setProperty("cameraShake", Double.toString(cameraShake));
        p.setProperty("dragonCameraDistance", Double.toString(dragonCameraDistance));
        p.setProperty("friendlyFire", Boolean.toString(friendlyFire));
        p.setProperty("cooldownMultiplier", Double.toString(cooldownMultiplier));
        try {
            Files.createDirectories(file.getParent());
            try (Writer w = Files.newBufferedWriter(file)) {
                p.store(w, "Grand Line: Quake & Azure — server/common configuration");
            }
        } catch (IOException e) {
            GrandLineQuakes.LOGGER.warn("Could not write config", e);
        }
    }

    private static boolean bool(Properties p, String k, boolean d) { return Boolean.parseBoolean(p.getProperty(k, Boolean.toString(d))); }
    private static int integer(Properties p, String k, int d) { try { return Integer.parseInt(p.getProperty(k, Integer.toString(d))); } catch (NumberFormatException e) { return d; } }
    private static double decimal(Properties p, String k, double d) { try { return Double.parseDouble(p.getProperty(k, Double.toString(d))); } catch (NumberFormatException e) { return d; } }
    private static int clamp(int v, int a, int b) { return Math.max(a, Math.min(b, v)); }
    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
}
