package dev.openai.grandline.state;

import com.mojang.serialization.Codec;
import dev.openai.grandline.GrandLineQuakes;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentTarget;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.network.codec.ByteBufCodecs;

import java.util.List;

public final class PowerState {
    public static final AttachmentType<Integer> FRUIT = syncedPersistentInt("fruit", 0, true);
    public static final AttachmentType<Integer> FORM = syncedPersistentInt("form", 0, false);
    public static final AttachmentType<Integer> ENERGY = syncedPersistentInt("energy", 100, true);
    public static final AttachmentType<Integer> ACTION = syncedInt("action", 0, true);
    public static final AttachmentType<Integer> ACTION_TICKS = syncedInt("action_ticks", 0, true);

    public static final AttachmentType<Long> COOLDOWN_1 = syncedLong("cooldown_1");
    public static final AttachmentType<Long> COOLDOWN_2 = syncedLong("cooldown_2");
    public static final AttachmentType<Long> COOLDOWN_3 = syncedLong("cooldown_3");
    public static final AttachmentType<Long> COOLDOWN_4 = syncedLong("cooldown_4");
    public static final AttachmentType<Long> COOLDOWN_5 = syncedLong("cooldown_5");
    private static final List<AttachmentType<Long>> COOLDOWNS = List.of(COOLDOWN_1, COOLDOWN_2, COOLDOWN_3, COOLDOWN_4, COOLDOWN_5);

    private PowerState() {}
    public static void initialize() { /* static registration is the initialization */ }

    private static AttachmentType<Integer> syncedPersistentInt(String id, int initial, boolean copyOnDeath) {
        return AttachmentRegistry.create(GrandLineQuakes.id(id), builder -> {
            var configured = builder
                    .initializer(() -> initial)
                    .persistent(Codec.INT)
                    .syncWith(ByteBufCodecs.INT, AttachmentSyncPredicate.all());
            return copyOnDeath ? configured.copyOnDeath() : configured;
        });
    }

    private static AttachmentType<Integer> syncedInt(String id, int initial, boolean all) {
        return AttachmentRegistry.create(GrandLineQuakes.id(id), builder -> builder
                .initializer(() -> initial)
                .syncWith(ByteBufCodecs.INT, all ? AttachmentSyncPredicate.all() : AttachmentSyncPredicate.targetOnly()));
    }

    private static AttachmentType<Long> syncedLong(String id) {
        return AttachmentRegistry.create(GrandLineQuakes.id(id), builder -> builder
                .initializer(() -> 0L)
                .persistent(Codec.LONG)
                .syncWith(ByteBufCodecs.LONG, AttachmentSyncPredicate.targetOnly())
                .copyOnDeath());
    }

    public static FruitPower fruit(AttachmentTarget target) {
        return FruitPower.fromId(target.getAttachedOrElse(FRUIT, 0));
    }
    public static DragonForm form(AttachmentTarget target) {
        return DragonForm.fromId(target.getAttachedOrElse(FORM, 0));
    }
    public static int energy(AttachmentTarget target) { return target.getAttachedOrElse(ENERGY, 100); }
    public static void setFruit(AttachmentTarget target, FruitPower fruit) { target.setAttached(FRUIT, fruit.id()); }
    public static void setForm(AttachmentTarget target, DragonForm form) { target.setAttached(FORM, form.id()); }
    public static void setEnergy(AttachmentTarget target, int value) { target.setAttached(ENERGY, Math.max(0, Math.min(100, value))); }
    public static long cooldownEnd(AttachmentTarget target, int slot) { return target.getAttachedOrElse(COOLDOWNS.get(slot - 1), 0L); }
    public static void setCooldownEnd(AttachmentTarget target, int slot, long tick) { target.setAttached(COOLDOWNS.get(slot - 1), tick); }
    public static void setAction(AttachmentTarget target, int actionId, int remainingTicks) {
        target.setAttached(ACTION, actionId);
        target.setAttached(ACTION_TICKS, remainingTicks);
    }
    public static int action(AttachmentTarget target) { return target.getAttachedOrElse(ACTION, 0); }
    public static int actionTicks(AttachmentTarget target) { return target.getAttachedOrElse(ACTION_TICKS, 0); }
}
