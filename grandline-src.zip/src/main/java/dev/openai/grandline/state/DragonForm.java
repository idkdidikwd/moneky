package dev.openai.grandline.state;

public enum DragonForm {
    HUMAN(0), HYBRID(1), DRAGON(2);

    private final int id;
    DragonForm(int id) { this.id = id; }
    public int id() { return id; }
    public static DragonForm fromId(int id) {
        return switch (id) {
            case 1 -> HYBRID;
            case 2 -> DRAGON;
            default -> HUMAN;
        };
    }
}
