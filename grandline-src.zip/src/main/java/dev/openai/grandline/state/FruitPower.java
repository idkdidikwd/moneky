package dev.openai.grandline.state;

public enum FruitPower {
    NONE(0), GURA(1), SEIRYU(2);

    private final int id;
    FruitPower(int id) { this.id = id; }
    public int id() { return id; }
    public static FruitPower fromId(int id) {
        return switch (id) {
            case 1 -> GURA;
            case 2 -> SEIRYU;
            default -> NONE;
        };
    }
}
