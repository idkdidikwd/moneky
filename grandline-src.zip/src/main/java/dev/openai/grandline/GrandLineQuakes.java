package dev.openai.grandline;

import dev.openai.grandline.ability.AbilityEngine;
import dev.openai.grandline.config.ModConfig;
import dev.openai.grandline.network.ModNetworking;
import dev.openai.grandline.registry.ModItems;
import dev.openai.grandline.registry.ModSounds;
import dev.openai.grandline.state.PowerState;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class GrandLineQuakes implements ModInitializer {
    public static final String MOD_ID = "grandlinequakes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModConfig.load();
        PowerState.initialize();
        ModSounds.initialize();
        ModItems.initialize();
        ModNetworking.initialize();
        AbilityEngine.initialize();
        LOGGER.info("Grand Line: Quake & Azure initialized for Minecraft 26.3 / Fabric Loader 0.19.5");
    }
}
