package dev.openai.grandline.api;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;

import java.util.UUID;

/**
 * Server-side protection hook for persistent world edits caused by Devil Fruit abilities.
 *
 * <p>Claim/protection mods or server-side compatibility addons can register a listener and return
 * {@code false} for protected positions. The callback is consulted for queued terrain destruction
 * and persistent ignition. It receives the UUID of the player who caused the edit, so integrations
 * do not need a client-side dependency or a retained live player reference.</p>
 */
@FunctionalInterface
public interface DestructionProtectionCallback {
    Event<DestructionProtectionCallback> EVENT = EventFactory.createArrayBacked(
            DestructionProtectionCallback.class,
            listeners -> (sourceId, level, pos, state) -> {
                for (DestructionProtectionCallback listener : listeners) {
                    if (!listener.allow(sourceId, level, pos, state)) return false;
                }
                return true;
            });

    boolean allow(UUID sourceId, ServerLevel level, BlockPos pos, BlockState state);
}
